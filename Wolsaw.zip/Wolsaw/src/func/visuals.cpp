#include "visuals.hpp"
#include "hitsounds.hpp"
#include "../game/game.hpp"
#include "../game/math.hpp"
#include "../game/player.hpp"
#include "../ui/theme/theme.hpp"
#include "../ui/cfg.hpp"
#include "../protect/oxorany.hpp"
#include "imgui.h"
#include <cmath>
#include <cstring>
#include <algorithm>
#include <unordered_map>
#include <unistd.h>
// ── New modules ──────────────────────────────────────────────────────────────
#include "radar.hpp"
#include "ambient_light.hpp"
#include "world.hpp"
#include "night_mode.hpp"
#include "norecoil.hpp"
#include "bullet_tracer.hpp"
#include "effects.hpp"
#include "../input/inject.hpp"

extern ImFont* espFont;
extern ImFont* wiconFont;

// LemmingRMT bone indices (matching their Body:: mapping)
namespace bone_idx {
    inline constexpr int Head = 10;
    inline constexpr int Neck = 9;
    inline constexpr int Chest = 8;
    inline constexpr int ChestAlt = 54;
    inline constexpr int Stomach = 7;
    inline constexpr int Pelvis = 0;
    inline constexpr int LShoulder = 11;
    inline constexpr int LElbow = 12;
    inline constexpr int LWrist = 13;
    inline constexpr int LHand = 14;
    inline constexpr int RShoulder = 15;
    inline constexpr int RElbow = 16;
    inline constexpr int RWrist = 17;
    inline constexpr int RHand = 18;
    inline constexpr int LHip = 1;
    inline constexpr int LKnee = 2;
    inline constexpr int LAnkle = 3;
    inline constexpr int LFoot = 4;
    inline constexpr int RHip = 5;
    inline constexpr int RKnee = 6;
    inline constexpr int RAnkle = 19;
    inline constexpr int RFoot = 20;
}

// Get bone world position for a player using the transform hierarchy.
// Returns true if successful and sets out_pos.
static bool get_player_bone_pos(uint64_t player, int bone_index, Vector3& out_pos,
                                uint64_t& sk_entries_ref, std::vector<int>& sk_pars_ref) {
    // Try to find the player's BipedMap component (same logic as skeleton ESP)
    const auto& lay = player::g_transform_layout;
    if (lay.pid != proc::pid || lay.data_offset < 0) return false;

    // Find BipedMap by scanning the player's component arrays
    // This is a simplified version - in production we'd cache the BipedMap per player
    static std::unordered_map<uint64_t, uint64_t> bip_cache;
    static long long bip_cache_time = 0;
    const long long now = diag::now_ms();
    if (now - bip_cache_time > 10000) {
        bip_cache.clear();
        bip_cache_time = now;
    }

    uint64_t bip = 0;
    auto it = bip_cache.find(player);
    if (it != bip_cache.end()) {
        bip = it->second;
    } else {
        // Scan for BipedMap: look at components under the player object
        const uint64_t player_obj = player; // managed player object
        if (!obj_ptr(player_obj)) return false;

        // Check the player's component arrays (simplified scan)
        for (uint64_t field = 0x10; field <= 0x38 && !bip; field += 8) {
            const uint64_t array = rpm<uint64_t>(player_obj + field);
            if (!plausible(array)) continue;
            const uint64_t count = rpm<uint64_t>(array + v100::array_length);
            if (count < 1 || count > 256) continue;
            for (uint64_t i = 0; i < count && !bip; ++i) {
                const uint64_t comp = rpm<uint64_t>(array + v100::array_data + i * 8);
                if (!obj_ptr(comp)) continue;
                // Check if this component has 22 transform fields at +0x20..+0xC8
                int ok = 0;
                for (int b = 0; b < 22; ++b) {
                    const uint64_t managed = rpm<uint64_t>(comp + 0x20 + uint64_t(b) * 8);
                    if (!obj_ptr(managed)) continue;
                    const uint64_t nat = rpm<uint64_t>(managed + v100::unity_cached_ptr);
                    if (!obj_ptr(nat)) continue;
                    Vector3 bp{}; Vector4 br{};
                    if (player::decode_transform_pose(nat, bp, br)) ++ok;
                }
                if (ok >= 12) { bip = comp; break; }
            }
        }
        if (bip) bip_cache[player] = bip;
    }

    if (!bip) return false;

    // Get the bone's managed transform and native pointer
    const uint64_t managed = rpm<uint64_t>(bip + 0x20 + uint64_t(bone_index) * 8);
    if (!obj_ptr(managed)) return false;
    const uint64_t nat = rpm<uint64_t>(managed + v100::unity_cached_ptr);
    if (!obj_ptr(nat)) return false;

    // Get the transform index
    if (lay.index_offset < 0) return false;
    const int idx = rpm<int>(nat + uint64_t(lay.index_offset));
    if (idx < 0 || idx >= 1048576) return false;

    // Get transform data pointers
    if (!sk_entries_ref) {
        const uint64_t data = rpm<uint64_t>(nat + uint64_t(lay.data_offset));
        if (!plausible(data)) return false;
        sk_entries_ref = rpm<uint64_t>(data + uint64_t(lay.entries_offset));
        const uint64_t parr = rpm<uint64_t>(data + uint64_t(lay.parents_offset));
        if (!plausible(sk_entries_ref) || !plausible(parr)) return false;

        // Read parents array
        std::vector<int> pars;
        const int kBlk = 4096, kMax = 262144;
        for (int base = 0; base < kMax; base += kBlk) {
            pars.resize((size_t)base + kBlk);
            if (!mem_read(parr + (uint64_t)base * sizeof(int), pars.data() + base,
                          (size_t)kBlk * sizeof(int))) {
                pars.resize((size_t)base);
                break;
            }
        }
        if (pars.size() < 1024) return false;
        sk_pars_ref = std::move(pars);
    }

    if (sk_pars_ref.size() < 1024 || idx >= (int)sk_pars_ref.size()) return false;

    // Get world position
    return player::world_pos_by_index_live(idx, sk_entries_ref, sk_pars_ref.data(), (int)sk_pars_ref.size(), out_pos);
}

// Visible check using hitbox colliders (LemmingRMT style).
// Reads the target's HitBoxColliders and checks if ray from camera
// to target bone intersects the hitbox. Also does a simple world
// geometry check by sampling points along the ray.
static bool is_visible(uint64_t target_player, Vector3 from, Vector3 to, int target_bone) {
    // Get target's BipedMap / hitbox colliders
    const auto& lay = player::g_transform_layout;
    if (lay.pid != proc::pid || lay.data_offset < 0) return true; // fallback allow

    // Find BipedMap for target
    uint64_t bip = 0;
    for (uint64_t field = 0x10; field <= 0x38 && !bip; field += 8) {
        const uint64_t array = rpm<uint64_t>(target_player + field);
        if (!plausible(array)) continue;
        const uint64_t count = rpm<uint64_t>(array + v100::array_length);
        if (count < 1 || count > 256) continue;
        for (uint64_t i = 0; i < count && !bip; ++i) {
            const uint64_t comp = rpm<uint64_t>(array + v100::array_data + i * 8);
            if (!obj_ptr(comp)) continue;
            int ok = 0;
            for (int b = 0; b < 22; ++b) {
                const uint64_t managed = rpm<uint64_t>(comp + 0x20 + uint64_t(b) * 8);
                if (!obj_ptr(managed)) continue;
                const uint64_t nat = rpm<uint64_t>(managed + v100::unity_cached_ptr);
                if (!obj_ptr(nat)) continue;
                Vector3 bp{}; Vector4 br{};
                if (player::decode_transform_pose(nat, bp, br)) ++ok;
            }
            if (ok >= 12) { bip = comp; break; }
        }
    }
    if (!bip) return true; // no bipedmap, allow

    // Get HitBoxColliders array from jgi part (LemmingRMT: part(p,"jgi"), offsets::field::jgi::kHitBoxColliders)
    // We'll scan for jgi component
    uint64_t jgi = 0;
    for (uint64_t field = 0x10; field <= 0x38 && !jgi; field += 8) {
        const uint64_t array = rpm<uint64_t>(target_player + field);
        if (!plausible(array)) continue;
        const uint64_t count = rpm<uint64_t>(array + v100::array_length);
        if (count < 1 || count > 256) continue;
        for (uint64_t i = 0; i < count && !jgi; ++i) {
            const uint64_t comp = rpm<uint64_t>(array + v100::array_data + i * 8);
            if (!obj_ptr(comp)) continue;
            // Check class name for "jgi" or "PlayerHitBoxes"
            const uint64_t klass = rpm<uint64_t>(comp);
            if (!plausible(klass)) continue;
            const uint64_t name_ptr = rpm<uint64_t>(klass + 0x10); // Il2CppClass::name
            if (!plausible(name_ptr)) continue;
            char name_buf[64] = {};
            if (!mem_read(name_ptr, name_buf, sizeof(name_buf) - 1)) continue;
            if (strstr(name_buf, "jgi") || strstr(name_buf, "HitBox") || strstr(name_buf, "PlayerHit")) {
                jgi = comp;
                break;
            }
        }
    }
    if (!jgi) return true; // no jgi, allow

    // jgi + 0x38 = HitBoxColliders array (LemmingRMT: offsets::field::jgi::kHitBoxColliders)
    const uint64_t hb_arr_obj = rpm<uint64_t>(jgi + 0x38);
    if (!plausible(hb_arr_obj)) return true;
    const uint64_t hb_arr = rpm<uint64_t>(hb_arr_obj + 0x10); // list->items
    const uint64_t hb_count = rpm<uint64_t>(hb_arr_obj + 0x18); // list->count
    if (!plausible(hb_arr) || hb_count == 0 || hb_count > 64) return true;

    // Ray from camera to target
    Vector3 dir = {to.x - from.x, to.y - from.y, to.z - from.z};
    float ray_len = std::sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);
    if (ray_len < 0.1f) return true;
    dir.x /= ray_len; dir.y /= ray_len; dir.z /= ray_len;

    // Check each hitbox collider
    for (uint64_t i = 0; i < hb_count; ++i) {
        const uint64_t hb = rpm<uint64_t>(hb_arr + i * 8);
        if (!obj_ptr(hb)) continue;
        // Check class name
        const uint64_t hb_klass = rpm<uint64_t>(hb);
        if (!plausible(hb_klass)) continue;
        const uint64_t hb_name_ptr = rpm<uint64_t>(hb_klass + 0x10);
        if (!plausible(hb_name_ptr)) continue;
        char hb_name[64] = {};
        if (!mem_read(hb_name_ptr, hb_name, sizeof(hb_name) - 1)) continue;
        if (!strstr(hb_name, "HitBoxCollider")) continue;

        // hb + 0x20 = bone index, hb + 0x28 = collider
        int hb_bone = rpm<int>(hb + 0x20);
        if (hb_bone != target_bone) continue;
        const uint64_t collider = rpm<uint64_t>(hb + 0x28);
        if (!obj_ptr(collider)) continue;

        // Get collider bounds (BoxCollider/CapsuleCollider/SphereCollider)
        const uint64_t col_nat = rpm<uint64_t>(collider + v100::unity_cached_ptr);
        if (!obj_ptr(col_nat)) continue;

        // Read bounds using the transform's world pose
        // We'll do a simple sphere check: get collider center via transform, estimate radius
        Vector3 col_center{}; Vector4 col_rot{};
        if (!player::decode_transform_pose(col_nat, col_center, col_rot)) continue;

        // Check ray-sphere intersection (approximate hitbox as sphere radius 0.3m)
        Vector3 oc = {from.x - col_center.x, from.y - col_center.y, from.z - col_center.z};
        float b = 2.f * (dir.x * oc.x + dir.y * oc.y + dir.z * oc.z);
        float c = oc.x * oc.x + oc.y * oc.y + oc.z * oc.z - 0.09f; // r=0.3
        float disc = b * b - 4.f * c;
        if (disc >= 0.f) {
            float t = (-b - std::sqrt(disc)) * 0.5f;
            if (t >= 0.f && t <= ray_len) {
                // Ray hits target's hitbox - visible!
                return true;
            }
        }
    }

    // Target's hitbox not hit - check if ray passes through world geometry
    // Simple heuristic: sample points along ray, if any point is inside a solid, blocked
    // We can't easily check world geometry externally, so we allow by default
    // but could add a simple "is point in wall" check by reading the navmesh or physics scene
    // For now, return true (conservative: assume visible if not hitting target hitbox)
    return true;
}

static void esp_wait(const char* stage) {
    static long long last = 0;
    if (diag::every(last, 5000)) diag::log("WAIT", "ESP blocked at: %s", stage);
}

void visuals::draw() {
    // Aimbot static state (function scope for visibility in all blocks)
    static int cam_leaf_idx = -1;
    static uint64_t cam_leaf_data = 0;
    static Vector4 hold_quat{0.f, 0.f, 0.f, 1.f};
    static float hold_yaw = 0.f;
    static bool hold_active = false;
    static uint64_t look_obj = 0;
    static int look_ord = 0;
    static float look_k = 1.f;
    static float look_c = 0.f;
    static uint64_t look_cands[12];
    static int look_nc = 0, look_next = 0;
    static long long look_scan_ms = -999999, look_probe_ms = 0;
    static bool look_found_once = false;

    bool any = cfg::esp::box || cfg::esp::name || cfg::esp::weapon || cfg::esp::health ||
               cfg::esp::distance || cfg::esp::snapline || cfg::esp::headdot ||
               cfg::esp::skeleton;
    if (!any) { esp_wait("all ESP options disabled"); return; }

    std::vector<uint64_t> Players = players();
    if (Players.empty()) { esp_wait("player discovery / registry scan"); return; }
    struct name_cache_entry { uint32_t id{}; std::string name; long long refreshed{}; };
    static std::unordered_map<uint64_t, name_cache_entry> name_cache;
    struct weapon_cache_entry { uint32_t id{}; std::string name; uint8_t wid{}; long long refreshed{}; bool probed{}; };
    static std::unordered_map<uint64_t, weapon_cache_entry> weapon_cache;
    static size_t name_cursor = 0;
    // Resolve at most one name + one weapon per frame. Discovery touches
    // several component objects, so batching all players caused UI stalls.
    {
        const uint64_t object = Players[name_cursor++ % Players.size()];
        const uint32_t id = rpm<uint32_t>(object + v100::net_object_id);
        const long long now = diag::now_ms();
        name_cache_entry& entry = name_cache[object];
        if (entry.id != id || now - entry.refreshed > 5000) {
            entry.id = id;
            entry.name = player_name(object);
            entry.refreshed = now;
        }
        weapon_cache_entry& wentry = weapon_cache[object];
        if (wentry.id != id || now - wentry.refreshed > 5000) {
            wentry.id = id;
            wentry.name = player::weapon_name(object, &wentry.wid);
            wentry.refreshed = now;
            wentry.probed = true;
        }
    }
    static long long object_log = 0;
    if (diag::every(object_log, 10000)) {
        for (size_t i = 0; i < Players.size(); ++i) {
            const uint64_t object = Players[i];
            const Vector3 position = player::position(object);
            std::string name_text = name_cache[object].name;
            if (name_text.empty()) name_text = "<name unavailable>";
            uint8_t wid = 0;
            std::string wname = player::weapon_name(object, &wid);
            if (wname.empty()) wname = "-";
            diag::log("PLAYER", "[%zu] object=0x%llx id=%u name=%s w=%s(%u) local=%d team=%d hp=%d pos=(%.3f %.3f %.3f)",
                      i, (unsigned long long)object, rpm<uint32_t>(object + v100::net_object_id),
                      name_text.c_str(), wname.c_str(), wid, player::local(object) ? 1 : 0, player::team(object),
                      player::health(object), position.x, position.y, position.z);
        }
    }
    uint64_t LocalPlayer = 0;
    for (uint64_t p : Players) if (player::local(p)) { LocalPlayer = p; break; }
    if (!LocalPlayer) { esp_wait("local player flag"); return; }

    // Alive tracking: on death the game zeroes the active weapon id while
    // hp/position freeze at their last values (verified over 20+ deaths:
    // wid reads the real gun while alive, 0 through the whole dead window).
    // Probe one player's weapon id per frame (round-robin, cheap); hide
    // armed players that read wid 0.
    struct alive_entry { uint32_t net_id{}; uint8_t wid{}; bool armed{}; bool has{}; };
    static std::unordered_map<uint64_t, alive_entry> alive_cache;
    static size_t alive_cursor = 0;
    if (!Players.empty()) {
        const uint64_t probe = Players[alive_cursor++ % Players.size()];
        const uint32_t nid = rpm<uint32_t>(probe + v100::net_object_id);
        uint8_t wid = 0;
        bool got = false;
        const std::vector<uint64_t> wps = player::find_weapon_parts(probe);
        if (!wps.empty()) {
            const uint64_t act = rpm<uint64_t>(wps[0] + 0x78);
            if (obj_ptr(act)) { wid = rpm<uint8_t>(act + 0x10); got = true; }
        }
        if (got) {
            alive_entry& e = alive_cache[probe];
            if (!e.has || e.net_id != nid) { e.net_id = nid; e.armed = false; e.has = true; }
            e.wid = wid;
            if (wid) e.armed = true;
        }
        if (alive_cache.size() > 24) {
            for (auto it = alive_cache.begin(); it != alive_cache.end();) {
                if (std::find(Players.begin(), Players.end(), it->first) == Players.end())
                    it = alive_cache.erase(it);
                else ++it;
            }
        }
    }
    auto is_dead = [&](uint64_t object) -> bool {
        auto it = alive_cache.find(object);
        return it != alive_cache.end() && it->second.has && it->second.armed && it->second.wid == 0;
    };
    // Name calibration: dump in-bounds strings of DIRECT-field targets
    // (player+0x58/0x68/0x78/0x80/0x88 objects), all players.
    static long long namecal = 0;
    static bool namecal_done = false;
    if (!namecal_done && diag::every(namecal, 5000)) {
        const uint64_t known_string = rpm<uint64_t>(proc::lib + v100::player_string_literal);
        const uint64_t string_class = plausible(known_string) ? rpm<uint64_t>(known_string) : 0;
        auto bounded_size = [](uint64_t klass) -> uint32_t {
            if (!plausible(klass)) return 0;
            const uint32_t sz = rpm<uint32_t>(klass + 0x60);
            return (sz >= 0x18 && sz <= 0x1000) ? sz : 0;
        };
        int total_shown = 0;
        if (string_class) {
            const uint64_t offs[5] = {0x58, 0x68, 0x78, 0x80, 0x88};
            for (uint64_t pl : Players) {
                const uint32_t pid = rpm<uint32_t>(pl + v100::net_object_id);
                const int is_local = player::local(pl) ? 1 : 0;
                for (int k = 0; k < 5 && total_shown < 120; ++k) {
                    const uint64_t tgt = rpm<uint64_t>(pl + offs[k]);
                    if (!obj_ptr(tgt)) continue;
                    const uint64_t ck = rpm<uint64_t>(tgt);
                    const uint32_t sz = bounded_size(ck);
                    if (sz < 0x18) continue;
                    const std::string tlabel = il2cpp::klass_label(ck);
                    for (uint64_t off = 0x10; off + 8 <= sz && total_shown < 120; off += 8) {
                        const uint64_t v = rpm<uint64_t>(tgt + off);
                        if (!obj_ptr(v) || rpm<uint64_t>(v) != string_class) continue;
                        const std::string s = read_managed_string(v, string_class);
                        if (s.empty() || s.size() > 48) continue;
                        diag::log("NAMED", "pid=%u local=%d poff=0x%02x %s size=0x%x off=0x%02llx str='%s'",
                                  pid, is_local, (unsigned)offs[k], tlabel.c_str(), sz,
                                  (unsigned long long)off, s.c_str());
                        ++total_shown;
                    }
                }
            }
        }
        diag::log("NAMED", "scan done strings=%d", total_shown);
        if (total_shown > 0) namecal_done = true;
    }
    Vector3 LocalPosition = player::position(LocalPlayer);
    int LocalTeam = player::team(LocalPlayer);
    if (LocalTeam != 1 && LocalTeam != 2) { esp_wait("local team validation"); return; }
    if (!std::isfinite(LocalPosition.x) ||
        (LocalPosition.x == 0.f && LocalPosition.y == 0.f && LocalPosition.z == 0.f)) {
        esp_wait("local transform hierarchy"); return;
    }
    // Overlay debug readout: what the local player holds right now.
    g_local = LocalPlayer;
    {
        uint8_t wid = 0;
        const std::string wn = player::weapon_name(LocalPlayer, &wid);
        g_local_wid = wid;
        std::snprintf(g_local_wname, sizeof(g_local_wname), "%s", wn.c_str());
    }

    // Scope state is not read from managed fields (they do not exist in this
    // dump); it is reflected by the live projection FOV of the selected
    // camera and exposed through player::g_live_fov below.



    int enemies = 0, alive = 0, positioned = 0, projected = 0, hidden_dead = 0;
    struct enemy_frame {
        uint64_t object{};
        Vector3 position{};
        int health{};
        float distance{};
    };
    std::vector<enemy_frame> frame_enemies;
    for (uint64_t Player : Players) {
        if (!Player || Player == LocalPlayer) continue;
        int PlayerTeam = player::team(Player);
        if (PlayerTeam == LocalTeam || (PlayerTeam != 1 && PlayerTeam != 2)) continue;
        if (is_dead(Player)) { ++hidden_dead; continue; }
        ++enemies;

        Vector3 PlayerPosition = player::position(Player);
        if (PlayerPosition.x == 0.f && PlayerPosition.y == 0.f && PlayerPosition.z == 0.f) continue;
        ++positioned;

        int Health = player::health(Player);
        if (Health <= 0) continue;
        ++alive;

        float Distance = calculate_distance(PlayerPosition, LocalPosition);
        if (Distance > 500.f) continue;

        frame_enemies.push_back({Player, PlayerPosition, Health, Distance});

        // Radar: передаём смещение от локального игрока (X/Z плоскость)
        radar::push(
            PlayerPosition.x - LocalPosition.x,
            PlayerPosition.z - LocalPosition.z,
            Health
        );
    }
    static long long dead_log = 0;
    if (hidden_dead && diag::every(dead_log, 5000))
        diag::log("ESP", "hiding %d dead players", hidden_dead);

    // Direct chain first: local player components -> managed Camera
    // (klass-name verified) -> native Camera -> live view/projection. When
    // that pair is sane (p[5] in [0.5,12] => FOV ~9.5..127 degrees) it is the
    // ONLY matrix source; the candidate-scoring path below is skipped so
    // jump/scope/crouch matrix tracking follows the real camera directly.
    matrix ViewMatrix{}, ProjectionMatrix{};
    uint64_t selected_camera = 0;
    bool direct_used = false;
    {
        matrix mv{}, mp{};
        uint64_t mn = 0;
        if (main_camera_matrices(LocalPlayer, mn, mv, mp) && mn) {
            const float* v = reinterpret_cast<const float*>(&mv);
            const float* p = reinterpret_cast<const float*>(&mp);
            const bool sane = p[5] >= 0.5f && p[5] <= 12.f &&
                              std::fabs(p[11]) > .5f && std::fabs(p[15]) < .1f &&
                              std::fabs(v[3]) < .001f && std::fabs(v[7]) < .001f &&
                              std::fabs(v[11]) < .001f && std::fabs(v[15] - 1.f) < .01f;
            if (sane) {
                ViewMatrix = mv;
                ProjectionMatrix = mp;
                selected_camera = mn;
                direct_used = true;
                g_camera = mn;
                player::g_live_fov = 2.f * std::atan(1.f / p[5]) * 57.29578f;
                static long long main_log = 0;
                if (diag::every(main_log, 5000))
                    diag::log("CAMERA", "direct main-cam native=0x%llx fov=%.1f proj=(%.3f %.3f)",
                              (unsigned long long)mn, player::g_live_fov, p[0], p[5]);
            } else {
                static long long reject_log = 0;
                if (diag::every(reject_log, 5000))
                    diag::log("CAMERA", "direct main-cam rejected native=0x%llx p5=%.3f p11=%.3f p15=%.3f",
                              (unsigned long long)mn, p[5], p[11], p[15]);
            }
        }
    }

    if (!direct_used) {
        // Fallback: score every validated candidate against the live player
        // coordinates. Projections that cannot represent a real FOV are
        // hard-rejected outright instead of being allowed to win on points.
        std::vector<camera_candidate> Cameras = camera_candidates(LocalPlayer);
        std::vector<camera_candidate> TransformCameras =
            player::camera_fallback_candidates(LocalPlayer);
        Cameras.insert(Cameras.end(), TransformCameras.begin(), TransformCameras.end());
        if (Cameras.empty()) { esp_wait("native / transform camera resolution"); return; }

        int selected_score = -1, selected_front = 0, selected_onscreen = 0;
        float selected_camera_distance = 1000000.f;
        static long long candidate_log = 0;
        const bool log_candidates = diag::every(candidate_log, 5000);
        for (const auto& Camera : Cameras) {
            const float* projection = reinterpret_cast<const float*>(&Camera.projection);
            const float p5 = projection[5];
            if (!(p5 >= 0.5f && p5 <= 12.f)) {
                if (log_candidates)
                    diag::log("CAMERA", "reject=0x%llx p5=%.3f (FOV out of 9.5..127 deg)",
                              (unsigned long long)Camera.address, p5);
                continue;
            }
            int score = 0, front = 0, onscreen = 0;
            const float* view = reinterpret_cast<const float*>(&Camera.view);
            const Vector3 camera_position(
                -(view[0] * view[12] + view[1] * view[13] + view[2] * view[14]),
                -(view[4] * view[12] + view[5] * view[13] + view[6] * view[14]),
                -(view[8] * view[12] + view[9] * view[13] + view[10] * view[14]));
            const float camera_distance = calculate_distance(camera_position, LocalPosition);
            if (camera_distance < 2.f) score += 100;
            else if (camera_distance < 10.f) score += 80;
            else if (camera_distance < 30.f) score += 30;
            if (std::fabs(projection[11]) > .5f && std::fabs(projection[15]) < .1f) score += 30;

            for (const auto& Enemy : frame_enemies) {
                Vector3 Head(Enemy.position.x, Enemy.position.y + 1.67f, Enemy.position.z);
                ImVec2 screen_head, screen_foot;
                if (!world_to_screen(Head, Camera.view, Camera.projection, screen_head) ||
                    !world_to_screen(Enemy.position, Camera.view, Camera.projection, screen_foot)) continue;
                if (!std::isfinite(screen_head.x) || !std::isfinite(screen_head.y) ||
                    !std::isfinite(screen_foot.x) || !std::isfinite(screen_foot.y)) continue;
                ++front;
                ++score;
                const bool head_inside = screen_head.x >= -g_sw * .25f && screen_head.x <= g_sw * 1.25f &&
                                         screen_head.y >= -g_sh * .25f && screen_head.y <= g_sh * 1.25f;
                const bool foot_inside = screen_foot.x >= -g_sw * .25f && screen_foot.x <= g_sw * 1.25f &&
                                         screen_foot.y >= -g_sh * .25f && screen_foot.y <= g_sh * 1.25f;
                const float body_height = std::fabs(screen_foot.y - screen_head.y);
                if (head_inside && foot_inside) { ++onscreen; score += 6; }
                if (body_height >= 2.f && body_height <= g_sh * 1.5f) score += 3;
            }
            // Keep the current winner on equal scores to avoid camera flicker.
            if (score > selected_score || (score == selected_score && Camera.address == g_camera)) {
                selected_score = score;
                selected_front = front;
                selected_onscreen = onscreen;
                selected_camera_distance = camera_distance;
                selected_camera = Camera.address;
            }
            if (log_candidates)
                diag::log("CAMERA", "candidate=0x%llx score=%d front=%d onscreen=%d localDistance=%.2f proj=(%.3f %.3f)",
                          (unsigned long long)Camera.address, score, front, onscreen, camera_distance,
                          Camera.projection.m11, Camera.projection.m22);
        }
        if (!selected_camera || (selected_camera_distance >= 30.f && selected_onscreen == 0)) {
            g_camera = 0;
            esp_wait("camera candidates do not project players");
            return;
        }
        if (g_camera != selected_camera) {
            diag::log("CAMERA", "selected=0x%llx score=%d front=%d onscreen=%d localDistance=%.2f candidates=%zu",
                      (unsigned long long)selected_camera, selected_score, selected_front,
                      selected_onscreen, selected_camera_distance, Cameras.size());
        }
        g_camera = selected_camera;

        // CRITICAL: Re-read view/proj from stored offsets EVERY FRAME.
        // Camera moves (jump/scope/rotate) change these matrices continuously.
        for (const auto& Camera : Cameras) {
            if (Camera.address == selected_camera) {
                if (Camera.view_off >= 0 && Camera.proj_off >= 0) {
                    mem_read(Camera.address + uint64_t(Camera.view_off), &ViewMatrix, sizeof(ViewMatrix));
                    mem_read(Camera.address + uint64_t(Camera.proj_off), &ProjectionMatrix, sizeof(ProjectionMatrix));
                } else {
                    ViewMatrix = Camera.view;
                    ProjectionMatrix = Camera.projection;
                }
                break;
            }
        }
        // Camera moves (jump/scope/rotate) change these matrices continuously.
        for (const auto& Camera : Cameras) {
            if (Camera.address == selected_camera) {
                if (Camera.view_off >= 0 && Camera.proj_off >= 0) {
                    mem_read(Camera.address + uint64_t(Camera.view_off), &ViewMatrix, sizeof(ViewMatrix));
                    mem_read(Camera.address + uint64_t(Camera.proj_off), &ProjectionMatrix, sizeof(ProjectionMatrix));
                } else {
                    ViewMatrix = Camera.view;
                    ProjectionMatrix = Camera.projection;
                }
                break;
            }
        }
        const float* fp = reinterpret_cast<const float*>(&ProjectionMatrix);
        if (fp[5] >= 0.5f && fp[5] <= 12.f)
            player::g_live_fov = 2.f * std::atan(1.f / fp[5]) * 57.29578f;
    }

    // ===== Aimbot =====
    if (cfg::aim::enabled && LocalPlayer) {
        // Extract view rotation from ViewMatrix (forward vector = -m[2], -m[6], -m[10])
        const float* vm = reinterpret_cast<const float*>(&ViewMatrix);
        Vector3 view_forward = {-vm[2], -vm[6], -vm[10]};
        float forward_len = std::sqrt(view_forward.x * view_forward.x + view_forward.y * view_forward.y + view_forward.z * view_forward.z);
            if (forward_len > 0.001f) {
                view_forward.x /= forward_len;
                view_forward.y /= forward_len;
                view_forward.z /= forward_len;

                // Camera eye position from the live view matrix. Aim angles are
                // computed FROM THE EYE: using the player root (feet) adds a
                // constant ~1.67m height bias that made the aimbot look above
                // the target (worse the closer the enemy).
                Vector3 campos{};
                bool have_campos = false;
                if (selected_camera) {
                    campos = Vector3(
                        -(vm[0] * vm[12] + vm[1] * vm[13] + vm[2] * vm[14]),
                        -(vm[4] * vm[12] + vm[5] * vm[13] + vm[6] * vm[14]),
                        -(vm[8] * vm[12] + vm[9] * vm[13] + vm[10] * vm[14]));
                    have_campos = std::isfinite(campos.x) && std::isfinite(campos.y) &&
                                  std::isfinite(campos.z);
                }
                const Vector3 aim_origin = have_campos ? campos : LocalPosition;
                static int cam_leaf_idx = -1;
                static uint64_t cam_leaf_data = 0;
                static Vector4 hold_quat{0.f, 0.f, 0.f, 1.f};
                static float hold_yaw = 0.f;
                static bool hold_active = false;
                static uint64_t look_obj = 0;
                static int look_ord = 0;
                static float look_k = 1.f;
                static float look_c = 0.f;
                static uint64_t look_cands[12];
                static int look_nc = 0, look_next = 0;
                static long long look_scan_ms = -999999, look_probe_ms = 0;
                static bool look_found_once = false;
                bool aim_wrote_this_tick = false;

                // Find best target within FOV
            float best_fov = cfg::aim::fov;
            uint64_t best_target = 0;
            Vector3 best_target_pos{};

            // Map cfg bone index to LemmingRMT bone indices
            static const int bone_map[5] = {
                bone_idx::Head,      // 0 = Head
                bone_idx::Neck,      // 1 = Neck
                bone_idx::Chest,     // 2 = Chest
                bone_idx::Stomach,   // 3 = Stomach
                bone_idx::Pelvis     // 4 = Pelvis
            };
            const int target_bone = bone_map[std::clamp(cfg::aim::bone, 0, 4)];

            // Cache for bone position lookups
            static std::unordered_map<uint64_t, std::pair<uint64_t, std::vector<int>>> bone_cache;
            static long long bone_cache_time = 0;
            const long long cache_now = diag::now_ms();
            if (cache_now - bone_cache_time > 5000) {
                bone_cache.clear();
                bone_cache_time = cache_now;
            }

            for (const auto& Enemy : frame_enemies) {
                if (!Enemy.object || Enemy.object == LocalPlayer) continue;
                if (cfg::aim::team_check) {
                    int eteam = player::team(Enemy.object);
                    if (eteam == LocalTeam) continue;
                }
                if (Enemy.health <= 0) continue;
                if (Enemy.distance > cfg::aim::max_dist) continue;

                // Get actual bone world position
                Vector3 target_pos{};
                uint64_t sk_entries = 0;
                std::vector<int> sk_pars;

                auto cache_it = bone_cache.find(Enemy.object);
                if (cache_it != bone_cache.end()) {
                    sk_entries = cache_it->second.first;
                    sk_pars = cache_it->second.second;
                }

                bool got_pos = get_player_bone_pos(Enemy.object, target_bone, target_pos, sk_entries, sk_pars);
                if (got_pos) {
                    bone_cache[Enemy.object] = {sk_entries, std::move(sk_pars)};
                } else {
                    // Fallback: approximate position
                    target_pos = Enemy.position;
                    if (target_bone == bone_idx::Head || target_bone == bone_idx::Neck)
                        target_pos.y += 1.67f;
                    else if (target_bone == bone_idx::Chest || target_bone == bone_idx::ChestAlt)
                        target_pos.y += 1.3f;
                    else if (target_bone == bone_idx::Stomach)
                        target_pos.y += 1.0f;
                    else
                        target_pos.y += 0.5f;
                }

                // Visible check
                if (cfg::aim::visible_check && !is_visible(Enemy.object, aim_origin, target_pos, target_bone)) {
                    continue;
                }

                Vector3 to_target = {
                    target_pos.x - aim_origin.x,
                    target_pos.y - aim_origin.y,
                    target_pos.z - aim_origin.z
                };
                float dist = std::sqrt(to_target.x * to_target.x + to_target.y * to_target.y + to_target.z * to_target.z);
                if (dist < 0.1f) continue;

                to_target.x /= dist;
                to_target.y /= dist;
                to_target.z /= dist;

                float dot = view_forward.x * to_target.x + view_forward.y * to_target.y + view_forward.z * to_target.z;
                if (dot > 1.f) dot = 1.f;
                if (dot < -1.f) dot = -1.f;
                float angle = std::acos(dot) * 57.29578f;

                // TargetMode 0 = ClosestFOV (default), 1 = LowHP, 2 = Distance
                bool better = false;
                if (cfg::aim::target_mode == 0) {
                    better = angle < best_fov;
                } else if (cfg::aim::target_mode == 1) {
                    // Lowest HP within FOV
                    if (angle < cfg::aim::fov) {
                        better = !best_target ||
                                 Enemy.health < player::health(best_target);
                    }
                } else if (cfg::aim::target_mode == 2) {
                    // Closest distance within FOV
                    if (angle < cfg::aim::fov) {
                        better = !best_target || Enemy.distance < best_fov;
                        if (better) best_fov = Enemy.distance;
                    }
                }
                if (better) {
                    if (cfg::aim::target_mode == 0) best_fov = angle;
                    best_target     = Enemy.object;
                    best_target_pos = target_pos;
                }
            }

            // ── Draw FOV circle ────────────────────────────────────────────
            if (cfg::aim::draw_fov) {
                // Конвертируем угол FOV в радиус в пикселях через проекцию
                ImDrawList* fov_dl = ImGui::GetBackgroundDrawList();
                float fov_rad = cfg::aim::fov;
                // Приближение: r = tan(fov/2 * PI/180) * screen_height * 0.5 / tan(camera_fov/2)
                float cam_fov_half = (player::g_live_fov > 0.f ? player::g_live_fov : 60.f) * 0.5f;
                float cam_tan = tanf(cam_fov_half * 0.01745329f);
                float aim_tan = tanf(fov_rad       * 0.01745329f);
                float pix_r = (cam_tan > 0.001f) ? (aim_tan / cam_tan) * g_sh * 0.5f : 0.f;
                if (pix_r > 2.f && pix_r < g_sw) {
                    ImVec2 sc = {g_sw * 0.5f, g_sh * 0.5f};
                    fov_dl->AddCircle(sc, pix_r,
                        best_target ? IM_COL32(255,80,80,100) : IM_COL32(255,255,255,55),
                        64, 1.2f);
                    // Дополнительный пунктирный круг (эстетика)
                    if (best_target) {
                        fov_dl->AddCircle(sc, pix_r + 2.f,
                            IM_COL32(255,60,60,40), 48, 0.7f);
                    }
                }
            }

            if (best_target) {
                // Calculate required rotation to aim at target (from the eye)
                Vector3 delta = {
                    best_target_pos.x - aim_origin.x,
                    best_target_pos.y - aim_origin.y,
                    best_target_pos.z - aim_origin.z
                };
                float tdist = std::sqrt(delta.x * delta.x + delta.y * delta.y + delta.z * delta.z);

                // Aim variables - declared here so they're in scope for controller/look/hold sections
                float cur_yaw = 0.f, target_yaw = 0.f, yaw_diff = 0.f;
                float cur_pitch = 0.f, target_pitch = 0.f, pitch_diff = 0.f;
                float smooth = 1.f;
                float new_yaw = 0.f, new_pitch = 0.f;
                float cy = 1.f, sy = 0.f, cp = 1.f, sp = 0.f;
                Vector4 new_quat = {0.f, 0.f, 0.f, 1.f};
                Vector4 yaw_quat = {0.f, 0.f, 0.f, 1.f};
                bool w_eir10 = false, w_eir20 = false;
                bool w_cam = false, w_p50 = false, w_p58 = false, w_weap = false, w_look = false;
                bool aim_wrote_this_tick = false;

                if (tdist > 0.01f) {
                    delta.x /= tdist;
                    delta.y /= tdist;
                    delta.z /= tdist;

                    // Calculate yaw/pitch difference
                    cur_yaw = std::atan2(view_forward.x, view_forward.z) * 57.29578f;
                    target_yaw = std::atan2(delta.x, delta.z) * 57.29578f;
                    yaw_diff = target_yaw - cur_yaw;
                    if (yaw_diff > 180.f) yaw_diff -= 360.f;
                    if (yaw_diff < -180.f) yaw_diff += 360.f;

                    cur_pitch = -std::asin(std::clamp(view_forward.y, -1.f, 1.f)) * 57.29578f;
                    target_pitch = -std::asin(std::clamp(delta.y, -1.f, 1.f)) * 57.29578f;
                    pitch_diff = target_pitch - cur_pitch;

                    // Apply smoothing (hard lock = instant snap, no smoothing)
                    smooth = cfg::aim::hard_lock ? 1.f : std::max(1.f, cfg::aim::smooth);
                    yaw_diff /= smooth;
                    pitch_diff /= smooth;

                    new_yaw = cur_yaw + yaw_diff;
                    new_pitch = cur_pitch + pitch_diff;
                    if (new_pitch > 89.f) new_pitch = 89.f;
                    if (new_pitch < -89.f) new_pitch = -89.f;

                    cy = std::cos(new_yaw * 0.00872664626f);
                    sy = std::sin(new_yaw * 0.00872664626f);
                    cp = std::cos(new_pitch * 0.00872664626f);
                    sp = std::sin(new_pitch * 0.00872664626f);

                    new_quat = { sp * cy, sy * cp, -sy * sp, cy * cp };
                    float n = std::sqrt(new_quat.x*new_quat.x + new_quat.y*new_quat.y + new_quat.z*new_quat.z + new_quat.w*new_quat.w);
                    if (n > 0.f) { new_quat.x /= n; new_quat.y /= n; new_quat.z /= n; new_quat.w /= n; }

                    yaw_quat = {0.f, sy, 0.f, cy};

                    // Camera leaf transform discovery lives below (leaf-index
                    // scan over the transform array): the old pointer-hopping
                    // scan never decoded and produced only vtable junk.

                    // Write corrected rotation. Steering targets confirmed by the
                    // slot experiment: pivot transforms (+0x50/+0x58) and the
                    // weapon-aim transform move the view; eir is kept in sync for
                    // network aim state.
                    const uint64_t ios_class = rpm<uint64_t>(proc::lib + v100::ios_typeinfo);
                    const uint64_t controller = find_player_component(LocalPlayer, ios_class);
                    const uint64_t aim_state = controller ? rpm<uint64_t>(controller + 0x38) : 0;
// eir aim state: absolute angles (full + yaw-only)
                        if (aim_state) {
                            w_eir10 = wpm<Vector4>(aim_state + 0x10, new_quat);
                            w_eir20 = wpm<Vector4>(aim_state + 0x20, yaw_quat);
                        }

                        // ---- camera LEAF transform discovery (index scan) ----
                        // Read the whole transform array + parent array into
                        // local memory, compose every index's world pose and
                        // pick the one sitting at the camera position with the
                        // camera's forward. The renderer reads this node every
                        // frame; writing it steers BOTH yaw and pitch and never
                        // touches ancestors (no position bob).
                        if (cam_leaf_idx < 0 && selected_camera && have_campos) {
                            static long long leaf_ms = -999999;
                            if (diag::every(leaf_ms, 4000)) {
                                const auto& lay = player::g_transform_layout;
                                const uint64_t piv = rpm<uint64_t>(controller + 0x50);
                                const uint64_t pn = piv ? rpm<uint64_t>(piv + v100::unity_cached_ptr) : 0;
                                if (lay.pid == proc::pid && lay.data_offset >= 0 && pn) {
                                    const uint64_t data = rpm<uint64_t>(pn + uint64_t(lay.data_offset));
                                    if (plausible(data)) {
                                        const uint64_t earr = rpm<uint64_t>(data + uint64_t(lay.entries_offset));
                                        const uint64_t parr = rpm<uint64_t>(data + uint64_t(lay.parents_offset));
                                        if (plausible(earr) && plausible(parr)) {
                                            const int kMax = 262144, kBlk = 4096;
                                            std::vector<player::TransformEntry> ents;
                                            std::vector<int> pars;
                                            for (int base = 0; base < kMax; base += kBlk) {
                                                ents.resize((size_t)base + kBlk);
                                                if (!mem_read(earr + (uint64_t)base * sizeof(player::TransformEntry),
                                                              ents.data() + base,
                                                              (size_t)kBlk * sizeof(player::TransformEntry))) {
                                                    ents.resize((size_t)base);
                                                    break;
                                                }
                                                pars.resize((size_t)base + kBlk);
                                                if (!mem_read(parr + (uint64_t)base * sizeof(int),
                                                              pars.data() + base,
                                                              (size_t)kBlk * sizeof(int))) {
                                                    pars.resize((size_t)base);
                                                    break;
                                                }
                                            }
                                            const int count = (int)std::min(ents.size(), pars.size());
                                            float best_dist = 1e9f, best_dot = -2.f;
                                            int best = -1;
                                            int under_pivot = -1;
                                            const int piv_idx = pn ? rpm<int>(pn + uint64_t(lay.index_offset)) : -1;
                                            for (int i = 0; i < count; ++i) {
                                                Vector3 wp; Vector4 wr;
                                                if (!player::compose_world_from_index(ents.data(), pars.data(),
                                                                                      count, i, wp, wr)) continue;
                                                const Vector3 f = player::rotate(wr, Vector3(0.f, 0.f, 1.f));
                                                const float dot = f.x * view_forward.x + f.y * view_forward.y +
                                                                  f.z * view_forward.z;
                                                const float dx = wp.x - campos.x, dy = wp.y - campos.y,
                                                            dz = wp.z - campos.z;
                                                const float dist = std::sqrt(dx * dx + dy * dy + dz * dz);
                                                if (dist < 1.f && dot > 0.99f) {
                                                    if (dist < best_dist ||
                                                        (dist == best_dist && dot > best_dot)) {
                                                        best = i; best_dist = dist; best_dot = dot;
                                                    }
                                                }
                                                if (piv_idx >= 0 && i != piv_idx) {
                                                    int c = i, g = 0;
                                                    while (c >= 0 && c < count && g++ < 64) {
                                                        if (c == piv_idx) { under_pivot = i; break; }
                                                        const int p = pars[c];
                                                        if (p == c) break;
                                                        c = p;
                                                    }
                                                }
                                            }
                                            if (best >= 0) {
                                                cam_leaf_idx = best;
                                                cam_leaf_data = data;
                                                diag::log("CAMT", "LEAF idx=%d dist=%.3f dot=%.3f count=%d underPiv=%d",
                                                          best, best_dist, best_dot, count, under_pivot);
                                            } else {
                                                diag::log("CAMT", "leaf scan no match count=%d campos=(%.2f,%.2f,%.2f) fwd=(%.3f,%.3f,%.3f)",
                                                          count, campos.x, campos.y, campos.z,
                                                          view_forward.x, view_forward.y, view_forward.z);
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // eir aim state: absolute angles (full + yaw-only)
                        if (aim_state) {
                            w_eir10 = wpm<Vector4>(aim_state + 0x10, new_quat);
                            const Vector4 yq{0.f, sy, 0.f, cy};
                            w_eir20 = wpm<Vector4>(aim_state + 0x20, yq);
                        }

                        // NOTE: writing the camera's view-matrix cache was tried
                        // and removed: the renderer does not read it, and ESP
                        // projects through it, so a mismatched pitch broke ESP.

                        // Yaw-only steering through the pivots + weapon-aim
                        // transform. Pitch is intentionally NOT written into the
                        // ancestor chain: tilting it swings the camera position
                        // vertically (underground dips) without ever steering
                        // the view pitch.
                        /* yaw_quat hoisted */
                        // ---- look accumulator discovery (the pitch channel) ----
                        // The game keeps absolute look angles in a touch/input
                        // object (yaw float +-180, pitch float +-90) and applies
                        // them itself every frame - no race if we write there.
                        // Scan the heap for the structural signature, then probe
                        // each candidate with a +6 deg pitch nudge and watch the
                        // live view for a matching movement.
                        auto read_view_pitch = [&]() -> float {
                            float m[16]{};
                            const int vo = g_main_cam.view_off >= 0 ? g_main_cam.view_off : 0x70;
                            if (!selected_camera || !mem_read(selected_camera + uint64_t(vo), m, sizeof(m)))
                                return 999.f;
                            const float fy = -m[6];
                            if (!std::isfinite(fy)) return 999.f;
                            return -std::asin(std::clamp(fy, -1.f, 1.f)) * 57.29578f;
                        };
                        // Scan when no look_obj, or periodically re-scan even if found (every 30s)
                        // to handle respawn/input object changes.
                        const long long look_now = diag::now_ms();
                        bool should_scan = (!look_obj || (look_found_once && look_now - look_scan_ms > 30000));
                        if (should_scan && look_nc == 0 && look_now - look_scan_ms > 8000 &&
                            std::fabs(cur_pitch) >= 1.5f) {
                                look_scan_ms = look_now;
                                const float cp = cur_pitch;
                                const std::string maps_path = "/proc/" + std::to_string(proc::pid) + "/maps";
                                FILE* mf = std::fopen(maps_path.c_str(), "r");
                                if (mf) {
                                    char line[512];
                                    std::vector<unsigned char> buf;
                                    while (look_nc < 12 && std::fgets(line, sizeof(line), mf)) {
                                        unsigned long long ra = 0, rb = 0;
                                        char perm[8]{};
                                        if (std::sscanf(line, "%llx-%llx %7s", &ra, &rb, perm) != 3) continue;
                                        if (perm[0] != 'r' || perm[1] != 'w') continue;
                                        if (ra < 0x100000000ULL) continue; // game heap lives in the
                                        const unsigned long long rsz = rb - ra; // high 64-bit range
                                        if (rsz < 0x100000 || rsz > 0x40000000) continue;
                                        if (std::strchr(line, '/')) continue; // anon + [heap] only
                                        const size_t chunk = 0x100000;
                                        buf.resize(chunk + 0x40);
                                        for (unsigned long long off = 0; off < rsz && look_nc < 12; off += chunk) {
                                            const size_t want = (size_t)std::min<unsigned long long>(chunk, rsz - off);
                                            if (!mem_read(ra + off, buf.data(), want)) continue;
                                            for (size_t i = 0; i + 0x28 <= want && look_nc < 12; i += 4) {
                                                unsigned char* o = buf.data() + i;
                                                uint64_t klass;
                                                std::memcpy(&klass, o, 8);
                                                if (!plausible(klass)) continue;
                                                float f14, f20, f24;
                                                std::memcpy(&f14, o + 0x14, 4);
                                                std::memcpy(&f20, o + 0x20, 4);
                                                std::memcpy(&f24, o + 0x24, 4);
                                                if (!std::isfinite(f14) || f14 < 0.f || f14 > 10000.f) continue;
                                                if (!std::isfinite(f20) || !std::isfinite(f24)) continue;
                                                if (std::fabs(f20) > 180.01f || std::fabs(f24) > 180.01f) continue;
                                                int ord = -1;
                                                if (std::fabs(f24 - cp) < 0.4f || std::fabs(f24 + cp) < 0.4f) ord = 0;
                                                else if (std::fabs(f20 - cp) < 0.4f || std::fabs(f20 + cp) < 0.4f) ord = 1;
                                                if (ord < 0) continue;
                                                const uint64_t obj = ra + off + i;
                                                bool dup = false;
                                                for (int d = 0; d < look_nc; ++d)
                                                    if (look_cands[d] == obj) { dup = true; break; }
                                                if (dup) continue;
                                                look_cands[look_nc++] = obj;
                                                diag::log("LOOK", "scan cand obj=0x%llx ord=%d f20=%.2f f24=%.2f cp=%.2f",
                                                          (unsigned long long)obj, ord, f20, f24, cp);
                                            }
                                        }
                                    }
                                    std::fclose(mf);
                                }
                                diag::log("LOOK", "scan done cands=%d cp=%.2f", look_nc, cp);
                            }
                            if (look_nc > 0 && look_next < look_nc && look_now - look_probe_ms > 400) {
                                look_probe_ms = look_now;
                                // Only probe while the view is stable: user drag
                                // would contaminate before/after deltas.
                                const float v1 = read_view_pitch();
                                usleep(15000);
                                const float v2 = read_view_pitch();
                                if (std::fabs(v2 - v1) > 1.5f || v1 > 900.f) {
                                    diag::log("LOOK", "probe hold cand=%d v=%.2f->%.2f",
                                              look_next, v1, v2);
                                } else {
                                const uint64_t cand = look_cands[look_next];
                                // Probe BOTH fields (+0x20 and +0x24). The old
                                // code picked a single "closest" field and
                                // skipped everything that didn't match cur_pitch
                                // directly - the real pitch state can be stored
                                // NEGATED (-cp) and was never being probed.
                                bool cand_found = false;
                                for (int ord = 0; ord < 2 && !cand_found; ++ord) {
                                    const uint64_t pfield = cand + (ord ? 0x20 : 0x24);
                                    const float orig = rpm<float>(pfield);
                                    const bool near_cp =
                                        std::fabs(orig - cur_pitch) <= 0.4f ||
                                        std::fabs(orig + cur_pitch) <= 0.4f ||
                                        std::fabs(orig) <= 0.4f;
                                    if (!near_cp)
                                        diag::log("LOOK", "probe far cand=%d ord=%d orig=%.2f cp=%.2f",
                                                  look_next, ord, orig, cur_pitch);
                                    const float before = read_view_pitch();
                                    const bool ok_w = wpm<float>(pfield, orig + 6.f);
                                    usleep(50000);
                                    const float after = read_view_pitch();
                                    wpm<float>(pfield, orig);
                                    usleep(20000);
                                    const float back = read_view_pitch();
                                    const float dv = after - before;
                                    diag::log("LOOK", "probe obj=0x%llx ord=%d orig=%.2f before=%.2f after=%.2f back=%.2f w=%d",
                                              (unsigned long long)cand, ord, orig, before, after, back, (int)ok_w);
                                    if (std::fabs(dv) > 1.5f && std::fabs(dv) < 12.f &&
                                        std::fabs(back - before) < 4.f) {
                                        look_obj = cand;
                                        look_ord = ord;
                                        look_k = dv / 6.f;
                                        look_c = before - look_k * orig;
                                        cand_found = true;
                                        look_found_once = true;
                                        diag::log("LOOK", "FOUND obj=0x%llx ord=%d k=%.2f c=%.2f",
                                                  (unsigned long long)look_obj, look_ord, look_k, look_c);
                                    }
                                }
                                ++look_next;
                                }
                            }
                            if (look_nc > 0 && look_next >= look_nc && !look_obj) {
                                look_nc = 0;
                                look_next = 0;
                            }

                            // The look pitch field reaches the camera through a
                        // DIFFERENT pipeline than the leaf transform. The leaf
                        // quat write steers yaw+position but the game reads pitch
                        // from the look accumulator. Must write BOTH for full lock.
                        if (look_obj && !cfg::aim::silent) {
                            const uint64_t pfield = look_obj + (look_ord ? 0x20 : 0x24);
                            w_look = wpm<float>(pfield, (new_pitch - look_c) / look_k);
                        }

                        // Refresh hold state on every live target: the full
                        // orientation (yaw+pitch) stays locked permanently.
                        hold_quat = new_quat;
                        hold_yaw = new_yaw;
                        hold_active = true;
                        aim_wrote_this_tick = true;

                        // Respawn handling: if local player died/respawned, reset camera cache
                        static uint64_t last_local_player = 0;
                        static int last_local_health = 100;
                        int cur_health = player::health(LocalPlayer);
                        if (LocalPlayer != last_local_player || cur_health > last_local_health) {
                            // Respawned or new local player
                            cam_leaf_idx = -1;
                            cam_leaf_data = 0;
                            look_obj = 0;
                            look_nc = 0;
                            look_next = 0;
                            look_ord = 0;
                            look_k = 1.f;
                            look_c = 0.f;
                            hold_active = false;
                        }
                        last_local_player = LocalPlayer;
                        last_local_health = cur_health;

                        // Pitch error monitoring: if look pitch diverges > 2 deg for 3+ frames, force re-discovery
                        static int pitch_error_frames = 0;
                        float pitch_err = std::fabs(cur_pitch - new_pitch);
                        if (pitch_err > 2.0f) {
                            ++pitch_error_frames;
                            if (pitch_error_frames >= 3) {
                                look_obj = 0;
                                look_nc = 0;
                                look_next = 0;
                                pitch_error_frames = 0;
                            }
                        } else {
                            pitch_error_frames = 0;
                        }

                        if (cam_leaf_idx >= 0 && !plausible(cam_leaf_data))
                            cam_leaf_idx = -1; // scene data moved; rescan
                        // Leaf transform ONLY takes YAW (pitch comes from look field).
                        // Writing pitch into leaf fights the look accumulator.
                        if (!cfg::aim::silent && cam_leaf_idx >= 0)
                            w_cam = player::set_world_rotation_by_index(cam_leaf_idx, cam_leaf_data, yaw_quat);
                        if (!cfg::aim::silent) {
                            auto write_pivot = [&](uint64_t off) -> bool {
                                const uint64_t managed = rpm<uint64_t>(controller + off);
                                const uint64_t native = managed ? rpm<uint64_t>(managed + v100::unity_cached_ptr) : 0;
                                return native ? player::set_transform_world_rotation(native, yaw_quat) : false;
                            };
                            w_p50 = write_pivot(0x50);
                            w_p58 = write_pivot(0x58);

                            const uint64_t wp_class = rpm<uint64_t>(proc::lib + v100::weapon_part_typeinfo);
                            const uint64_t part = wp_class ? player::find_part(LocalPlayer, wp_class) : 0;
                            const uint64_t am = part ? rpm<uint64_t>(part + 0x40) : 0;
                            const uint64_t wnat = am ? rpm<uint64_t>(am + v100::unity_cached_ptr) : 0;
                            w_weap = wnat ? player::set_transform_world_rotation(wnat, yaw_quat) : false;
                        }

                        // Dense re-assert: leaf transform (yaw) and pitch field.
                        if (cfg::aim::enabled && (w_cam || w_look)) {
                            for (int b = 0; b < 16; ++b) {
                                if (w_cam)
                                    player::set_world_rotation_by_index(cam_leaf_idx, cam_leaf_data, yaw_quat);
                                if (look_obj)
                                    wpm<float>(look_obj + (look_ord ? 0x20 : 0x24),
                                               (new_pitch - look_c) / look_k);
                                usleep(100);
                            }
                        }

                        static long long aimw_log = 0;
                        if (diag::every(aimw_log, 1000)) {
                            diag::log("AIMW", "eir=%d/%d leaf=%d piv=%d/%d weap=%d look=%d sil=%d cur=(%.1f,%.1f) new=(%.1f,%.1f)",
                                      (int)w_eir10, (int)w_eir20, (int)w_cam, (int)w_p50, (int)w_p58, (int)w_weap,
                                      (int)w_look, (int)cfg::aim::silent, cur_yaw, cur_pitch, new_yaw, new_pitch);
                        }
                    }

                    static long long aim_log = 0;
                    if (diag::every(aim_log, 1000)) {
diag::log("AIM", "target found dist=%.1f yaw=%.1f pitch=%.1f", tdist, yaw_diff, pitch_diff);
                    }
                }

        // ===== Permanent full-orientation hold: while aimbot is enabled
            // the view NEVER becomes free. With a target the normal path
            // follows it every tick; without one the last commanded full
            // rotation (yaw AND pitch) is re-asserted every tick forever.
            if (cfg::aim::enabled && !cfg::aim::silent && hold_active && cam_leaf_idx >= 0 &&
                plausible(cam_leaf_data) && !aim_wrote_this_tick) {
                for (int b = 0; b < 2; ++b) {
                    // Leaf: yaw only. Pitch comes from look field.
                    float cy = std::cos(hold_yaw * 0.00872664626f);
                    float sy = std::sin(hold_yaw * 0.00872664626f);
                    Vector4 hold_yaw_quat{0.f, sy, 0.f, cy};
                    player::set_world_rotation_by_index(cam_leaf_idx, cam_leaf_data, hold_yaw_quat);
                    if (look_obj) {
                        // Extract pitch from hold_quat: pitch = -asin(2*(q.y*q.z - q.w*q.x)) in Y-up Z-forward
                        float sp = 2.f * (hold_quat.y * hold_quat.z - hold_quat.w * hold_quat.x);
                        float hold_pitch = -std::asin(std::clamp(sp, -1.f, 1.f)) * 57.29578f;
                        const uint64_t pfield = look_obj + (look_ord ? 0x20 : 0x24);
                        wpm<float>(pfield, (hold_pitch - look_c) / look_k);
                    }
                    usleep(50);
                }
                static long long hold_log = 0;
                if (diag::every(hold_log, 2000))
                    diag::log("AIMH", "full hold active");
            }
        }
    }
    // ===== End Aimbot =====

    // ===== Triggerbot =====
    if (cfg::settings::triggerbot && LocalPlayer) {
        static long long tb_last_fire_ms = 0;
        static long long tb_delay_end_ms = 0;
        static bool      tb_in_delay     = false;
        const long long  tb_now          = diag::now_ms();

        // Определяем: смотрим ли мы на врага (цель в прицеле)
        // Используем те же данные что и аимбот: извлекаем forward из ViewMatrix
        const float* vm  = reinterpret_cast<const float*>(&ViewMatrix);
        Vector3 fwd = {-vm[2], -vm[6], -vm[10]};
        float flen = std::sqrt(fwd.x*fwd.x+fwd.y*fwd.y+fwd.z*fwd.z);
        if (flen > 0.001f) { fwd.x/=flen; fwd.y/=flen; fwd.z/=flen; }

        // Камера-оригин
        Vector3 eye = {};
        if (selected_camera) {
            eye = Vector3(
                -(vm[0]*vm[12]+vm[1]*vm[13]+vm[2]*vm[14]),
                -(vm[4]*vm[12]+vm[5]*vm[13]+vm[6]*vm[14]),
                -(vm[8]*vm[12]+vm[9]*vm[13]+vm[10]*vm[14]));
        } else { eye = LocalPosition; }

        bool on_target = false;
        for (const auto& Enemy : frame_enemies) {
            if (!Enemy.object || Enemy.object == LocalPlayer) continue;
            if (Enemy.health <= 0) continue;
            if (cfg::aim::team_check && player::team(Enemy.object) == LocalTeam) continue;

            // Позиция центра тела
            Vector3 tp = Enemy.position;
            tp.y += 1.2f; // центр торса

            Vector3 d = { tp.x-eye.x, tp.y-eye.y, tp.z-eye.z };
            float dd = std::sqrt(d.x*d.x+d.y*d.y+d.z*d.z);
            if (dd < 0.1f || dd > cfg::aim::max_dist) continue;
            d.x/=dd; d.y/=dd; d.z/=dd;
            float dot = fwd.x*d.x + fwd.y*d.y + fwd.z*d.z;
            dot = dot<-1.f?-1.f:(dot>1.f?1.f:dot);
            float ang = std::acos(dot)*57.29578f;

            // Triggerbot FOV = 2 градуса (очень узко — только прямо в прицеле)
            const float TB_FOV = 2.5f;
            if (ang < TB_FOV) {
                // Visible check для тригербота
                if (cfg::settings::tb_visible_check &&
                    !is_visible(Enemy.object, eye, tp, bone_idx::Chest))
                    continue;
                on_target = true;
                break;
            }
        }

        // Optional physical tap-fire path from MyFolder. Requires root and calibrated button coordinates.
        const ImVec2 tb_screen = ImGui::GetIO().DisplaySize;
        inject::set_screen(tb_screen.x, tb_screen.y);
        if (cfg::settings::tb_tap_fire && on_target) {
            static long long tb_last_tap_ms = 0;
            if (tb_now - tb_last_tap_ms >= std::max(80, cfg::settings::tb_interval)) {
                const float fx = std::clamp(cfg::settings::tb_fire_x_pct / 100.f, 0.f, 1.f) * tb_screen.x;
                const float fy = std::clamp(cfg::settings::tb_fire_y_pct / 100.f, 0.f, 1.f) * tb_screen.y;
                if (inject::request_tap(fx, fy)) tb_last_tap_ms = tb_now;
            }
        }

        // Only when aiming (прицеливание = живой FOV меньше camera_fov * 0.7)
        bool aiming_ok = true;
        if (cfg::settings::tb_only_ads) {
            float live_fov = player::g_live_fov;
            // Если игрок целится (ADS) — FOV уменьшается
            aiming_ok = (live_fov > 1.f && live_fov < 55.f);
        }

        if (on_target && aiming_ok) {
            if (!tb_in_delay) {
                tb_in_delay   = true;
                tb_delay_end_ms = tb_now + (long long)cfg::settings::tb_delay;
            }
            if (tb_now >= tb_delay_end_ms &&
                tb_now - tb_last_fire_ms >= cfg::settings::tb_interval) {
                // Симулируем нажатие — пишем в aim_state fire signal
                // В отличие от аимбота, тригербот не двигает камеру:
                // он только подтверждает выстрел через eir fire-pulse
                const uint64_t ios_class = rpm<uint64_t>(proc::lib + v100::ios_typeinfo);
                const uint64_t ctrl      = find_player_component(LocalPlayer, ios_class);
                if (ctrl) {
                    const uint64_t aim_st = rpm<uint64_t>(ctrl + 0x38);
                    if (aim_st) {
                        // Записываем fire flag (byte offset +0x30 = shoot trigger, confirmed in diag)
                        uint8_t fire_flag = 1;
                        wpm<uint8_t>(aim_st + 0x30, fire_flag);
                    }
                }
                tb_last_fire_ms = tb_now;
            }
        } else {
            tb_in_delay   = false;
            tb_delay_end_ms = 0;
        }
    }
    // ===== End Triggerbot =====

    // ── Bullet Tracer: hit-detection via HP drop ────────────────────────────
    // Статическая карта последних HP для каждого врага.
    // При падении HP — создаём трейс от локального игрока к врагу.
    static std::unordered_map<uint64_t, int> tracer_prev_hp;
    if (cfg::tracer::enabled || cfg::settings::hit_sound) {
        // Чистим мёртвых/ушедших игроков раз в 5 сек
        static long long tracer_clean_t = 0;
        if (diag::every(tracer_clean_t, 5000)) {
            std::vector<uint64_t> dead_keys;
            dead_keys.reserve(tracer_prev_hp.size());
            for (const auto& kv : tracer_prev_hp) {
                bool found = false;
                for (const auto& e : frame_enemies)
                    if (e.object == kv.first) { found = true; break; }
                if (!found) dead_keys.push_back(kv.first);
            }
            for (uint64_t k : dead_keys) tracer_prev_hp.erase(k);
        }
        for (const auto& Enemy : frame_enemies) {
            auto it = tracer_prev_hp.find(Enemy.object);
            if (it == tracer_prev_hp.end()) {
                tracer_prev_hp[Enemy.object] = Enemy.health;
                continue;
            }
            int prev_hp = it->second;
            int cur_hp  = Enemy.health;
            // Declare impact here so it is visible in both the hit and death blocks
            Vector3 impact(Enemy.position.x, Enemy.position.y + 1.2f, Enemy.position.z);
            if (cur_hp < prev_hp && cur_hp > 0) {
                // Tracer and hit sound are independent toggles.
                if (cfg::tracer::enabled) {
                    Vector3 local_head(LocalPosition.x, LocalPosition.y + 1.67f, LocalPosition.z);
                    bullet_tracer::push(local_head, impact);
                }
                if (cfg::settings::hit_sound) hitsounds::on_hit(cfg::settings::hit_sound_type);
                // Hit particles at screen position of impact
                ImVec2 hm_sp;
                if (world_to_screen(impact, ViewMatrix, ProjectionMatrix, hm_sp)) {
                    effects::spawn_hit(hm_sp.x, hm_sp.y);
                }
            }
            // Death effect: HP went to 0
            if (prev_hp > 0 && cur_hp <= 0) {
                ImVec2 death_sp;
                Vector3 dp(Enemy.position.x, Enemy.position.y + 1.f, Enemy.position.z);
                if (world_to_screen(dp, ViewMatrix, ProjectionMatrix, death_sp)) {
                    effects::spawn_death(death_sp.x, death_sp.y);
                    effects::spawn_death_ring(death_sp.x, death_sp.y);
                }
                // Hit marker — spawn at impact screen pos
                if (cfg::misc::hitmarker) {
                    ImVec2 hm_sp;
                    if (world_to_screen(impact, ViewMatrix, ProjectionMatrix, hm_sp)) {
                        struct HitMarkS { float x,y,t; };
                        static std::vector<HitMarkS> hm_spawn;
                        hm_spawn.push_back({hm_sp.x, hm_sp.y, 0.f});
                    }
                }
            }
            it->second = cur_hp;
        }
    }
    // ───────────────────────────────────────────────────────────────────────

    for (const auto& Enemy : frame_enemies) {
        const uint64_t Player = Enemy.object;
        const Vector3 PlayerPosition = Enemy.position;
        const int Health = Enemy.health;
        const float Distance = Enemy.distance;

        Vector3 HeadPosition(PlayerPosition.x, PlayerPosition.y + 1.67f, PlayerPosition.z);

        ImVec2 ScreenHead, ScreenFoot;
        bool HeadVisible = world_to_screen(HeadPosition, ViewMatrix, ProjectionMatrix, ScreenHead);
        bool FootVisible = world_to_screen(PlayerPosition, ViewMatrix, ProjectionMatrix, ScreenFoot);
        if (!HeadVisible || !FootVisible) continue;
        ++projected;

        float x1 = roundf(ScreenHead.x);
        float y1 = roundf(fminf(ScreenHead.y, ScreenFoot.y));
        float x2 = roundf(ScreenFoot.x);
        float y2 = roundf(fmaxf(ScreenHead.y, ScreenFoot.y));

        float bh = fabsf(y2 - y1);
        float bw = roundf(bh * 0.21f);
        float cx = roundf((x1 + x2) * 0.5f);

        ImVec2 BoxMin(cx - bw, y1 + 1.f);
        ImVec2 BoxMax(cx + bw, y2 - 1.f);

        float inv_dist = 1.f / (Distance + 0.1f);
        float font_sz = std::clamp(320.f * inv_dist, 8.f, 13.f);

        // ── Gradient / visible-color resolve ────────────────────────────────
        // Normalise distance 0..1 over the configured max_dist
        float dist_t = std::clamp(Distance / (cfg::esp::max_dist > 1.f ? cfg::esp::max_dist : 300.f), 0.f, 1.f);
        // Interpolate near→far colour
        auto lerp_col = [](const ImVec4& a, const ImVec4& b, float t) -> ImU32 {
            return IM_COL32(
                (int)((a.x + (b.x-a.x)*t)*255),
                (int)((a.y + (b.y-a.y)*t)*255),
                (int)((a.z + (b.z-a.z)*t)*255),
                255);
        };
        ImU32 grad_col;
        if (cfg::esp_extra::gradient) {
            grad_col = lerp_col(cfg::esp_extra::grad_near, cfg::esp_extra::grad_far, dist_t);
        } else {
            const auto& bc = cfg::esp::box_col;
            grad_col = IM_COL32((int)(bc.x*255),(int)(bc.y*255),(int)(bc.z*255),255);
        }

        // ── Box Glow (soft outer halo before box) ───────────────────────────
        if (cfg::esp::box && cfg::esp_extra::glow) {
            ImDrawList* gdl = ImGui::GetBackgroundDrawList();
            float gs   = cfg::esp_extra::glow_size;
            float ga   = cfg::esp_extra::glow_alpha;
            ImVec4 gc  = ImGui::ColorConvertU32ToFloat4(grad_col);
            const int gsteps = 6;
            for (int gi = gsteps; gi >= 1; gi--) {
                float t2   = (float)gi / (float)gsteps;
                float exp2 = gs * t2;
                int   aa   = (int)(ga * (1.f - t2) * 255.f);
                if (aa < 2) continue;
                ImU32 gc2  = IM_COL32((int)(gc.x*255),(int)(gc.y*255),(int)(gc.z*255), aa);
                gdl->AddRect(
                    ImVec2(BoxMin.x - exp2, BoxMin.y - exp2),
                    ImVec2(BoxMax.x + exp2, BoxMax.y + exp2),
                    gc2, 2.f + exp2 * 0.3f, 0, 1.f);
            }
        }

        if (cfg::esp::box) {
            dbox(BoxMin, BoxMax, 1.f, grad_col);
        }

        if (cfg::esp::health) {
            dhp(Health, BoxMin, BoxMax, bh, 1.f);
        }

        if (cfg::esp::name) {
            const auto found = name_cache.find(Player);
            const char* label = found != name_cache.end() && !found->second.name.empty()
                ? found->second.name.c_str() : "Enemy";
            dnick(label, BoxMax, cx, font_sz, 1.f);
        }

        if (cfg::esp::weapon) {
            const auto wfound = weapon_cache.find(Player);
            if (wfound != weapon_cache.end() &&
                (!wfound->second.name.empty() || wfound->second.wid)) {
                const float wy = BoxMax.y + 4.f + font_sz + 2.f;
                const char icon = player::weapon_icon(wfound->second.wid);
                if (icon && wiconFont) {
                    // Icons read small at ESP text scale; draw them a bit larger.
                    dwicon(icon, cx, wy - 2.f, std::max(11.f, font_sz * 1.7f), 1.f);
                } else if (!wfound->second.name.empty()) {
                    dweapon(wfound->second.name.c_str(), cx, wy, std::max(7.f, font_sz - 1.5f), 1.f);
                }
            }
        }

        if (cfg::esp::distance) {
            ddist(Distance, BoxMax.x, BoxMin.y, font_sz, 1.f);
        }

        ImDrawList* edl = ImGui::GetBackgroundDrawList();
        if (cfg::esp::snapline) {
            // Gradient snapline: bottom=accent colour, top=transparent
            ImU32 snap_bottom = grad_col;
            ImU32 snap_top    = (snap_bottom & 0x00FFFFFF) | 0x28000000; // very transparent
            edl->AddLine(ImVec2(g_sw * 0.5f, g_sh),
                         ImVec2(cx, y2),
                         snap_bottom, 1.f);
            (void)snap_top; // kept for possible multi-colour line extension
        }

        if (cfg::esp::headdot) {
            float r = std::clamp(bw * 0.22f, 2.f, 8.f);
            ImVec2 hc((x1 + x2) * 0.5f, y1 + r * 0.6f);
            // Head dot uses gradient colour with a white core
            edl->AddCircleFilled(hc, r + 1.5f, IM_COL32(0,0,0,120), 16);
            edl->AddCircleFilled(hc, r, grad_col, 16);
            edl->AddCircleFilled(hc, r * 0.45f, IM_COL32(255,255,255,220), 12);
        }

        // ===== Skeleton ESP =====
        // No BipedMap hunt (unreachable + the component scan lagged the game).
        // The character's own transform is the hierarchy root; every bone is
        // a descendant of it. Bones = subtree nodes within 2.8m of the
        // player; each node is drawn as a line to its parent (the hierarchy
        // IS the skeleton: spine, limbs, etc.).
        if (cfg::esp::skeleton) {
            struct SkelRig { int root; std::vector<int> bones; long long checked; };
            static std::unordered_map<uint64_t, SkelRig> rigs;
            static uint64_t sk_entries = 0;
            static std::vector<int> sk_pars;
            static long long sk_pars_ms = 0;
            const long long sk_now = diag::now_ms();
            const auto& sk_lay = player::g_transform_layout;
            auto sk_refresh_parents = [&](uint64_t nat) {
                if (!nat || sk_lay.pid != proc::pid || sk_lay.data_offset < 0) return;
                const uint64_t data = rpm<uint64_t>(nat + uint64_t(sk_lay.data_offset));
                if (!plausible(data)) return;
                const uint64_t earr = rpm<uint64_t>(data + uint64_t(sk_lay.entries_offset));
                const uint64_t parr = rpm<uint64_t>(data + uint64_t(sk_lay.parents_offset));
                if (!plausible(earr) || !plausible(parr)) return;
                std::vector<int> pars;
                const int kBlk = 4096, kMax = 262144;
                for (int base = 0; base < kMax; base += kBlk) {
                    pars.resize((size_t)base + kBlk);
                    if (!mem_read(parr + (uint64_t)base * sizeof(int), pars.data() + base,
                                  (size_t)kBlk * sizeof(int))) {
                        pars.resize((size_t)base);
                        break;
                    }
                }
                if (pars.size() < 1024) return;
                sk_entries = earr; sk_pars = std::move(pars);
                sk_pars_ms = sk_now;
            };
            SkelRig& rig = rigs[Player];
            static int sk_rr = 0;
            const bool sk_turn = (sk_rr++ % 150) == 0;
            const bool sk_fail = rig.root < 0 || rig.bones.empty();
            const bool sk_due = sk_fail ? sk_now - rig.checked > 30000
                                        : sk_now - rig.checked > 15000;
            if (sk_due && sk_turn) {
                rig.checked = sk_now;
                rig.root = -1;
                rig.bones.clear();
                const auto t_cands = player::transform_candidates(Player);
                int best_kept = 0, best_root = -1, cand_roots = 0;
                int dbg_ridx = -1, dbg_sub = 0, dbg_kept = 0;
                float dbg_rdist = -1.f;
                std::vector<int> best_bones;
                std::vector<int> stack, out, kept;
                std::vector<int> csr_start, csr_adj;
                int csr_pcount = 0;
                auto sk_build_csr = [&]() {
                    const int pcount = (int)sk_pars.size();
                    csr_start.assign((size_t)pcount + 1, 0);
                    for (int i = 0; i < pcount; ++i) {
                        const int p = sk_pars[(size_t)i];
                        if (p >= 0 && p < pcount && p != i) ++csr_start[(size_t)p + 1];
                    }
                    for (int i = 0; i < pcount; ++i) csr_start[(size_t)i + 1] += csr_start[(size_t)i];
                    csr_adj.assign((size_t)pcount, 0);
                    std::vector<int> cursor(csr_start.begin(), csr_start.end() - 1);
                    for (int i = 0; i < pcount; ++i) {
                        const int p = sk_pars[(size_t)i];
                        if (p >= 0 && p < pcount && p != i) csr_adj[(size_t)cursor[p]++] = i;
                    }
                    csr_pcount = pcount;
                };
                for (uint64_t mt : t_cands) {
                    const uint64_t nat = mt ? rpm<uint64_t>(mt + v100::unity_cached_ptr) : 0;
                    if (!obj_ptr(nat)) continue;
                    if (sk_lay.pid != proc::pid || sk_lay.index_offset < 0) continue;
                    const int ridx = rpm<int>(nat + uint64_t(sk_lay.index_offset));
                    if (ridx < 0 || ridx >= 1048576) continue;
                    ++cand_roots;
                    if (sk_pars.empty() || sk_now - sk_pars_ms > 5000) sk_refresh_parents(nat);
                    if (sk_pars.size() < 1024) continue;
                    const int pcount = (int)sk_pars.size();
                    if (ridx >= pcount) continue;
                    // Root sanity: the character root sits at the player's feet.
                    Vector3 rp{};
                    float rdist = -1.f;
                    if (player::world_pos_by_index_live(ridx, sk_entries, sk_pars.data(), pcount, rp)) {
                        const float dx = rp.x - PlayerPosition.x;
                        const float dy = rp.y - PlayerPosition.y;
                        const float dz = rp.z - PlayerPosition.z;
                        rdist = std::sqrt(dx * dx + dy * dy + dz * dz);
                    }
                    dbg_ridx = ridx; dbg_rdist = rdist;
                    if (rdist < 0.f || rdist > 2.0f) continue;
                    // BFS children via counting sort (CSR), size capped.
                    if (csr_pcount != pcount) sk_build_csr();
                    out.clear();
                    stack.clear();
                    stack.push_back(ridx);
                    int guard = 0;
                    while (!stack.empty() && guard++ < 512 && out.size() < 300) {
                        const int node = stack.back();
                        stack.pop_back();
                        for (int k = csr_start[(size_t)node]; k < csr_start[(size_t)node + 1]; ++k) {
                            const int child = csr_adj[(size_t)k];
                            out.push_back(child);
                            stack.push_back(child);
                        }
                    }
                    dbg_sub = (int)out.size();
                    kept.clear();
                    kept.reserve(out.size());
                    for (int b : out) {
                        Vector3 wp{};
                        if (!player::world_pos_by_index_live(b, sk_entries, sk_pars.data(), pcount, wp))
                            continue;
                        const float dx = wp.x - PlayerPosition.x;
                        const float dy = wp.y - PlayerPosition.y;
                        const float dz = wp.z - PlayerPosition.z;
                        if (dx * dx + dy * dy + dz * dz <= 2.8f * 2.8f) kept.push_back(b);
                    }
                    dbg_kept = (int)kept.size();
                    if ((int)kept.size() > best_kept) {
                        best_kept = (int)kept.size();
                        best_bones = std::move(kept);
                        best_root = ridx;
                    }
                }
                if (best_root >= 0 && best_kept >= 12) {
                    rig.root = best_root;
                    rig.bones = std::move(best_bones);
                    std::sort(rig.bones.begin(), rig.bones.end());
                    diag::log("SKEL", "found player=0x%llx root=%d bones=%d cands=%d",
                              (unsigned long long)Player, rig.root, best_kept, cand_roots);
                } else {
                    diag::log("SKEL", "not found player=0x%llx kept=%d cands=%d lastRidx=%d lastDist=%.2f lastSub=%d lastKept=%d",
                              (unsigned long long)Player, best_kept, cand_roots,
                              dbg_ridx, dbg_rdist, dbg_sub, dbg_kept);
                }
            }
            if (rig.root >= 0 && !rig.bones.empty() && sk_entries && sk_pars.size() >= 1024) {
                const int pcount = (int)sk_pars.size();
                Vector3 root_pos{};
                const bool root_ok =
                    player::world_pos_by_index_live(rig.root, sk_entries, sk_pars.data(), pcount, root_pos);
                ImVec2 root_sp{};
                const bool root_sok =
                    root_ok && world_to_screen(root_pos, ViewMatrix, ProjectionMatrix, root_sp);
                const ImU32 sk_col = IM_COL32(int(cfg::esp::skel_col.x * 255),
                                              int(cfg::esp::skel_col.y * 255),
                                              int(cfg::esp::skel_col.z * 255),
                                              int(cfg::esp::skel_col.w * 255));
                int drawn = 0, nw = 0;
                static long long skd_log = 0;
                const bool skd = diag::every(skd_log, 10000);
                for (int b : rig.bones) {
                    if (b < 0 || b >= pcount) continue;
                    Vector3 wp{};
                    if (!player::world_pos_by_index_live(b, sk_entries, sk_pars.data(), pcount, wp))
                        continue;
                    ++nw;
                    const float dx = wp.x - PlayerPosition.x;
                    const float dy = wp.y - PlayerPosition.y;
                    const float dz = wp.z - PlayerPosition.z;
                    if (dx * dx + dy * dy + dz * dz > 2.8f * 2.8f) continue;
                    const int p = sk_pars[(size_t)b];
                    const bool p_is_root = (p == rig.root);
                    const bool p_in = p >= 0 && p < pcount &&
                                      std::binary_search(rig.bones.begin(), rig.bones.end(), p);
                    if (!p_is_root && !p_in) continue;
                    Vector3 pp{};
                    if (p_is_root) {
                        if (!root_ok) continue;
                        pp = root_pos;
                    } else {
                        if (!player::world_pos_by_index_live(p, sk_entries, sk_pars.data(), pcount, pp))
                            continue;
                    }
                    const float sdx = wp.x - pp.x, sdy = wp.y - pp.y, sdz = wp.z - pp.z;
                    if (sdx * sdx + sdy * sdy + sdz * sdz > 1.3f * 1.3f) continue;
                    ImVec2 sp{}, psp{};
                    if (!world_to_screen(wp, ViewMatrix, ProjectionMatrix, sp)) continue;
                    if (p_is_root) {
                        if (!root_sok) continue;
                        psp = root_sp;
                    } else {
                        if (!world_to_screen(pp, ViewMatrix, ProjectionMatrix, psp)) continue;
                    }
                    edl->AddLine(psp, sp, sk_col, 1.5f);
                    ++drawn;
                }
                if (skd)
                    diag::log("SKELD", "p=0x%llx root=%d nodes=%zu wok=%d drawn=%d epos=(%.2f,%.2f,%.2f)",
                              (unsigned long long)Player, rig.root, rig.bones.size(), nw, drawn,
                              PlayerPosition.x, PlayerPosition.y, PlayerPosition.z);
            }
        }
    }
    static long long frame_log = 0;
    if (diag::every(frame_log, 5000)) {
        diag::log(projected ? "INFO" : "WARN",
                  "ESP frame players=%zu local=0x%llx team=%d pos=(%.2f %.2f %.2f) enemies=%d positioned=%d alive=%d projected=%d camera=0x%llx",
                  Players.size(), (unsigned long long)LocalPlayer, LocalTeam,
                  LocalPosition.x, LocalPosition.y, LocalPosition.z, enemies, positioned, alive,
                  projected, (unsigned long long)g_camera);
    }

    // ── Post-frame overlays & memory modules ────────────────────────────────
    ImDrawList* post_dl = ImGui::GetBackgroundDrawList();

    // Bullet Tracers
    bullet_tracer::draw(post_dl, ViewMatrix, ProjectionMatrix);

    // Mini Radar
    radar::draw(post_dl);

    // Ambient Light
    ambient_light::run();

    // Potato GFX
    world::run();

    // Night Mode
    night_mode::run();

    // No Recoil stub
    norecoil::tick(LocalPlayer);

    // Effects: rain + particles + death rings
    effects::tick(post_dl, ImGui::GetIO().DeltaTime);


    // ── Crosshair ────────────────────────────────────────────────────────────
    if (cfg::misc::crosshair) {
        const float cx = g_sw * 0.5f, cy = g_sh * 0.5f;
        const float sz  = cfg::misc::crosshair_size;
        const float gap = cfg::misc::crosshair_gap;
        const float th  = cfg::misc::crosshair_thick;
        ImU32 cc = IM_COL32(
            (int)(cfg::misc::crosshair_col.x*255),
            (int)(cfg::misc::crosshair_col.y*255),
            (int)(cfg::misc::crosshair_col.z*255),
            (int)(cfg::misc::crosshair_col.w*255));
        ImU32 cs = IM_COL32(0,0,0,160); // shadow
        int style = cfg::misc::crosshair_style;
        // Cross
        if (style==0||style==3) {
            post_dl->AddLine({cx-sz-gap,cy},{cx-gap,cy},cs,th+1.5f);
            post_dl->AddLine({cx+gap,cy},{cx+sz+gap,cy},cs,th+1.5f);
            post_dl->AddLine({cx,cy-sz-gap},{cx,cy-gap},cs,th+1.5f);
            post_dl->AddLine({cx,cy+gap},{cx,cy+sz+gap},cs,th+1.5f);
            post_dl->AddLine({cx-sz-gap,cy},{cx-gap,cy},cc,th);
            post_dl->AddLine({cx+gap,cy},{cx+sz+gap,cy},cc,th);
            post_dl->AddLine({cx,cy-sz-gap},{cx,cy-gap},cc,th);
            post_dl->AddLine({cx,cy+gap},{cx,cy+sz+gap},cc,th);
        }
        // Dot
        if (style==1) {
            post_dl->AddCircleFilled({cx,cy},th+1.5f,cs,12);
            post_dl->AddCircleFilled({cx,cy},th,cc,12);
        }
        // Circle
        if (style==2||style==3) {
            post_dl->AddCircle({cx,cy},sz+gap,cs,32,th+1.f);
            post_dl->AddCircle({cx,cy},sz+gap,cc,32,th);
        }
    }

    // ── Hit Marker ───────────────────────────────────────────────────────────
    {
        struct HitMark { float x,y,t; };
        static std::vector<HitMark> hm_marks;
        // Collect pending from tracer detection pass
        static std::vector<HitMark> hm_pending;
        for (auto& pm : hm_pending)
            hm_marks.push_back(pm);
        hm_pending.clear();

        if (cfg::misc::hitmarker) {
            float dt_hm = ImGui::GetIO().DeltaTime;
            for (auto& m : hm_marks) m.t += dt_hm;
            hm_marks.erase(std::remove_if(hm_marks.begin(),hm_marks.end(),
                [](const HitMark& m){return m.t>=cfg::misc::hitmarker_dur;}),
                hm_marks.end());
            for (auto& m : hm_marks) {
                float a = 1.f - m.t/cfg::misc::hitmarker_dur;
                ImU32 c = IM_COL32(
                    (int)(cfg::misc::hitmarker_col.x*255),
                    (int)(cfg::misc::hitmarker_col.y*255),
                    (int)(cfg::misc::hitmarker_col.z*255),(int)(a*255));
                float s = cfg::misc::hitmarker_size;
                float s2 = s*0.35f;
                post_dl->AddLine({m.x-s,m.y-s},{m.x-s2,m.y-s2},c,1.5f);
                post_dl->AddLine({m.x+s,m.y-s},{m.x+s2,m.y-s2},c,1.5f);
                post_dl->AddLine({m.x-s,m.y+s},{m.x-s2,m.y+s2},c,1.5f);
                post_dl->AddLine({m.x+s,m.y+s},{m.x+s2,m.y+s2},c,1.5f);
            }
        } else {
            hm_marks.clear();
        }
    }
}

void visuals::dbox(const ImVec2& t, const ImVec2& b, float a, ImU32 override_col) {
    if (a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    float x1 = t.x, y1 = t.y, x2 = b.x, y2 = b.y;
    float r = cfg::esp::box_rounding;

    ImU32 col;
    if (override_col != 0) {
        // Apply alpha from 'a' to the override colour
        ImVec4 ov = ImGui::ColorConvertU32ToFloat4(override_col);
        col = IM_COL32((int)(ov.x*255),(int)(ov.y*255),(int)(ov.z*255),(int)(ov.w*255*a));
    } else {
        col = IM_COL32(
            static_cast<int>(cfg::esp::box_col.x * 255),
            static_cast<int>(cfg::esp::box_col.y * 255),
            static_cast<int>(cfg::esp::box_col.z * 255),
            static_cast<int>(cfg::esp::box_col.w * 255 * a)
        );
    }

    if (cfg::esp::box_type == 0) {
        // ── 2D solid box ──────────────────────────────────────────────────
        dl->AddRect(ImVec2(x1, y1), ImVec2(x2, y2), IM_COL32(0, 0, 0, (int)(170 * a)), r, 0, 2.f);
        dl->AddRect(ImVec2(x1, y1), ImVec2(x2, y2), col, r, 0, 1.f);
    } else if (cfg::esp::box_type == 2) {
        // ── 3D box (perspective quad projected from screen bbox) ──────────
        // We simulate depth by drawing a second shrunken box offset upward
        // and connecting the four corners with lines — giving the illusion of
        // a 3-D cuboid drawn in screen space without needing world positions.
        float w = x2 - x1, h = y2 - y1;
        float dep_x = w * 0.12f;   // perspective depth offset X
        float dep_y = h * 0.10f;   // perspective depth offset Y

        // Front face corners (same as 2D box)
        ImVec2 f_tl(x1, y1), f_tr(x2, y1), f_bl(x1, y2), f_br(x2, y2);
        // Back face corners (inset + offset = "behind" the player)
        ImVec2 b_tl(x1 + dep_x, y1 - dep_y);
        ImVec2 b_tr(x2 - dep_x, y1 - dep_y);
        ImVec2 b_bl(x1 + dep_x, y2 - dep_y);
        ImVec2 b_br(x2 - dep_x, y2 - dep_y);

        ImU32 shadow = IM_COL32(0, 0, 0, (int)(140 * a));
        // Draw shadows slightly offset
        auto line2 = [&](ImVec2 a2, ImVec2 b2) {
            dl->AddLine(ImVec2(a2.x+1.5f,a2.y+1.5f), ImVec2(b2.x+1.5f,b2.y+1.5f), shadow, 1.5f);
        };
        // Back face shadow
        line2(b_tl,b_tr); line2(b_tr,b_br); line2(b_br,b_bl); line2(b_bl,b_tl);
        // Connecting edges shadow
        line2(f_tl,b_tl); line2(f_tr,b_tr); line2(f_bl,b_bl); line2(f_br,b_br);
        // Front face shadow
        line2(f_tl,f_tr); line2(f_tr,f_br); line2(f_br,f_bl); line2(f_bl,f_tl);

        // Back face (dimmer)
        ImVec4 cv = ImGui::ColorConvertU32ToFloat4(col);
        ImU32 col_dim = IM_COL32((int)(cv.x*180),(int)(cv.y*180),(int)(cv.z*180),(int)(cv.w*255*a*0.55f));
        dl->AddLine(b_tl,b_tr,col_dim,1.f); dl->AddLine(b_tr,b_br,col_dim,1.f);
        dl->AddLine(b_br,b_bl,col_dim,1.f); dl->AddLine(b_bl,b_tl,col_dim,1.f);
        // Connecting edges
        ImU32 col_edge = IM_COL32((int)(cv.x*200),(int)(cv.y*200),(int)(cv.z*200),(int)(cv.w*255*a*0.7f));
        dl->AddLine(f_tl,b_tl,col_edge,1.f); dl->AddLine(f_tr,b_tr,col_edge,1.f);
        dl->AddLine(f_bl,b_bl,col_edge,1.f); dl->AddLine(f_br,b_br,col_edge,1.f);
        // Front face (full brightness)
        dl->AddLine(f_tl,f_tr,col,1.f); dl->AddLine(f_tr,f_br,col,1.f);
        dl->AddLine(f_br,f_bl,col,1.f); dl->AddLine(f_bl,f_tl,col,1.f);
    } else {
        float w = x2 - x1, h = y2 - y1;
        float sz = std::min(w, h) * 0.25f;
        float cr = std::min(r, sz * 0.5f);

        ImU32 s1 = IM_COL32(0, 0, 0, (int)(90 * a));
        ImU32 s2 = IM_COL32(0, 0, 0, (int)(170 * a));

        auto corner = [&](float cx, float cy, float dx, float dy) {
            if (cr > 0.5f) {
                float arc_cx = cx + dx * cr;
                float arc_cy = cy + dy * cr;

                float angle_start, angle_end;
                if (dx > 0 && dy > 0) { angle_start = 3.14159265f; angle_end = 4.71238898f; }
                else if (dx < 0 && dy > 0) { angle_start = 4.71238898f; angle_end = 6.28318530f; }
                else if (dx > 0 && dy < 0) { angle_start = 1.57079632f; angle_end = 3.14159265f; }
                else { angle_start = 0.f; angle_end = 1.57079632f; }

                dl->PathArcTo(ImVec2(arc_cx + 2.f * (dx > 0 ? 1 : -1), arc_cy + 2.f * (dy > 0 ? 1 : -1)), cr, angle_start, angle_end, 8);
                dl->PathStroke(s1, 0, 2.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + dx * sz, cy + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * cr), ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * sz), s1, 2.f);

                dl->PathArcTo(ImVec2(arc_cx, arc_cy), cr, angle_start, angle_end, 8);
                dl->PathStroke(s2, 0, 1.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy), ImVec2(cx + dx * sz, cy), s2, 1.f);
                dl->AddLine(ImVec2(cx, cy + dy * cr), ImVec2(cx, cy + dy * sz), s2, 1.f);

                dl->PathArcTo(ImVec2(arc_cx, arc_cy), cr, angle_start, angle_end, 8);
                dl->PathStroke(col, 0, 1.f);
                dl->AddLine(ImVec2(cx + dx * cr, cy), ImVec2(cx + dx * sz, cy), col, 1.f);
                dl->AddLine(ImVec2(cx, cy + dy * cr), ImVec2(cx, cy + dy * sz), col, 1.f);
            } else {
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + dx * sz + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);
                dl->AddLine(ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + 2.f * (dy > 0 ? 1 : -1)), ImVec2(cx + 2.f * (dx > 0 ? 1 : -1), cy + dy * sz + 2.f * (dy > 0 ? 1 : -1)), s1, 2.f);

                dl->AddLine(ImVec2(cx, cy), ImVec2(cx + dx * sz, cy), s2, 1.f);
                dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + dy * sz), s2, 1.f);

                dl->AddLine(ImVec2(cx, cy), ImVec2(cx + dx * sz, cy), col, 1.f);
                dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + dy * sz), col, 1.f);
            }
        };

        corner(x1, y1, 1, 1);
        corner(x2, y1, -1, 1);
        corner(x1, y2, 1, -1);
        corner(x2, y2, -1, -1);
    }
}

void visuals::dhp(int hp, const ImVec2& t, const ImVec2& b, float box_h, float a) {
    if (a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    hp = std::clamp(hp, 0, 100);
    float pct = hp / 100.f;

    float bx = roundf(t.x - 6.f);
    float bw = 3.f;
    float bh = roundf(b.y - t.y);
    float fh = bh * pct;

    float top_y = t.y;
    float bot_y = b.y;
    float fill_top = roundf(bot_y - fh);

    // Background track
    dl->AddRectFilled(ImVec2(bx - 2.f, top_y - 2.f), ImVec2(bx + bw + 2.f, bot_y + 2.f),
                      IM_COL32(0, 0, 0, (int)(130 * a)), 2.f);
    dl->AddRectFilled(ImVec2(bx, top_y), ImVec2(bx + bw, bot_y),
                      IM_COL32(20, 20, 20, (int)(180 * a)), 1.f);

    if (fh > 1.f) {
        // Dynamic green→yellow→red gradient based on HP %
        // full HP = green (#1EFF6E), mid = yellow (#FFD700), low = red (#FF2D2D)
        int rT, gT, bT, rB, gB, bB;
        if (pct >= 0.5f) {
            float t2 = (pct - 0.5f) * 2.f;  // 1=full, 0=50%
            rT = (int)(0x1E + (0xFF - 0x1E) * (1.f - t2));   // green→yellow (top)
            gT = (int)(0xFF - (0xFF - 0xD7) * (1.f - t2));
            bT = (int)(0x6E * t2);
        } else {
            float t2 = pct * 2.f;            // 1=50%, 0=empty
            rT = (int)(0xFF);
            gT = (int)(0xD7 * t2);
            bT = 0;
        }
        rB = (int)(rT * 0.7f); gB = (int)(gT * 0.7f); bB = (int)(bT * 0.7f);
        ImU32 col_top2 = IM_COL32(rT, gT, bT, (int)(255 * a));
        ImU32 col_bot2 = IM_COL32(rB, gB, bB, (int)(255 * a));
        dl->AddRectFilledMultiColor(
            ImVec2(bx, fill_top), ImVec2(bx + bw, bot_y),
            col_top2, col_top2, col_bot2, col_bot2);
        // Subtle shine line on left edge
        dl->AddLine(ImVec2(bx, fill_top), ImVec2(bx, bot_y),
                    IM_COL32(255,255,255,(int)(30*a)), 1.f);
    }

    if (hp < 100 && espFont && bh > 20.f) {
        char txt[8];
        snprintf(txt, sizeof(txt), "%d", hp);
        float fs = 8.f;
        ImVec2 ts = espFont->CalcTextSizeA(fs, FLT_MAX, 0.f, txt);
        float tx = roundf(bx + (bw - ts.x) * 0.5f);
        float ty = roundf(fill_top - ts.y * 0.5f);
        if (ty < top_y) ty = top_y;
        if (ty + ts.y > bot_y) ty = bot_y - ts.y;
        draw_text_outlined(dl, espFont, fs, ImVec2(tx, ty), IM_COL32(255, 255, 255, (int)(255 * a)), txt);
    }
}

void visuals::dnick(const char* name, const ImVec2& box_max, float cx, float sz, float a) {
    if (!espFont || a < 0.01f || !name) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    ImVec2 ts = espFont->CalcTextSizeA(sz, FLT_MAX, 0.f, name);
    ImVec2 tp(roundf(cx - ts.x * 0.5f), roundf(box_max.y + 4.f));

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::name_col.x * 255),
        static_cast<int>(cfg::esp::name_col.y * 255),
        static_cast<int>(cfg::esp::name_col.z * 255),
        static_cast<int>(cfg::esp::name_col.w * 255 * a)
    );
    draw_text_outlined(dl, espFont, sz, tp, col, name);
}

void visuals::dweapon(const char* weapon, float cx, float y, float sz, float a) {
    if (!espFont || a < 0.01f || !weapon || !weapon[0]) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    ImVec2 ts = espFont->CalcTextSizeA(sz, FLT_MAX, 0.f, weapon);
    ImVec2 tp(roundf(cx - ts.x * 0.5f), roundf(y));

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::weapon_col.x * 255),
        static_cast<int>(cfg::esp::weapon_col.y * 255),
        static_cast<int>(cfg::esp::weapon_col.z * 255),
        static_cast<int>(cfg::esp::weapon_col.w * 255 * a)
    );
    draw_text_outlined(dl, espFont, sz, tp, col, weapon);
}

void visuals::dwicon(char icon, float cx, float y, float sz, float a) {
    if (!wiconFont || a < 0.01f || !icon) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    char txt[2] = { icon, 0 };
    ImVec2 ts = wiconFont->CalcTextSizeA(sz, FLT_MAX, 0.f, txt);
    ImVec2 tp(roundf(cx - ts.x * 0.5f), roundf(y));

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::weapon_col.x * 255),
        static_cast<int>(cfg::esp::weapon_col.y * 255),
        static_cast<int>(cfg::esp::weapon_col.z * 255),
        static_cast<int>(cfg::esp::weapon_col.w * 255 * a)
    );
    draw_text_outlined(dl, wiconFont, sz, tp, col, txt);
}

void visuals::ddist(float dist, float x, float y, float sz, float a) {
    if (!espFont || a < 0.01f) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();

    char txt[16];
    snprintf(txt, sizeof(txt), "%dm", static_cast<int>(dist));

    ImVec2 tp(roundf(x + 5.f), roundf(y));

    ImU32 col = IM_COL32(
        static_cast<int>(cfg::esp::distance_col.x * 255),
        static_cast<int>(cfg::esp::distance_col.y * 255),
        static_cast<int>(cfg::esp::distance_col.z * 255),
        static_cast<int>(cfg::esp::distance_col.w * 255 * a)
    );
    draw_text_outlined(dl, espFont, sz, tp, col, txt);
}

void visuals::draw_text_outlined(ImDrawList* dl, ImFont* font, float size, const ImVec2& pos, ImU32 color, const char* text) {
    if (!font || !dl) return;

    int a = (color >> IM_COL32_A_SHIFT) & 0xFF;
    int s1 = static_cast<int>(a * 0.4f);
    int s2 = static_cast<int>(a * 0.7f);

    dl->AddText(font, size, ImVec2(pos.x + 2.f, pos.y + 2.f), IM_COL32(0, 0, 0, s1), text);
    dl->AddText(font, size, ImVec2(pos.x + 1.f, pos.y + 1.f), IM_COL32(0, 0, 0, s2), text);
    dl->AddText(font, size, pos, color, text);
}
