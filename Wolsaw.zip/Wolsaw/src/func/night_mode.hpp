#pragma once
// ─────────────────────────────────────────────────────────────────────────────
//  night_mode.hpp  —  Night Mode (исправленный)
//  Lua: gg.setRanges(gg.REGION_ANONYMOUS) → только анонимные регионы
//       searchNumber("9D;1073741824D::21", TYPE_AUTO)
//       refineNumber("1073741824", TYPE_DWORD)
//       patch → 1056964608
//  Ключевое исправление: сканируем ТОЛЬКО анонимные регионы (без /dev/shm,
//  без файловых маппингов, только heap/anonymous) — именно там Unity
//  держит RenderSettings.ambientLight.
// ─────────────────────────────────────────────────────────────────────────────
#include <sys/uio.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <vector>
#include <thread>
#include <atomic>
#include "../other/memory.hpp"
#include "../ui/cfg.hpp"

namespace night_mode {

// Lua: searchNumber("9D;1073741824D::21") — ищем DW 9 следом DW 1073741824
// с шагом ≤21 DWORDs между ними.
static const uint32_t NM_SEARCH = 1073741824u; // 0x40000000
static const uint32_t NM_PATCH  = 1056964608u; // 0x3F000000 (~0.5 интенсивности)
static const uint32_t NM_ANCHOR = 9u;
static const int      NM_STRIDE = 21;          // макс DWORD-расстояние от anchor

struct AddrVal { uint64_t addr; uint32_t orig; };
static std::vector<AddrVal> g_bk;
static std::atomic<bool>    g_busy{false};
static bool                 g_last = false;
static int                  g_last_pid = -1;  // tracks pid to detect new match

static bool nm_read(uint64_t a, void* b, size_t l) {
    if (proc::pid<=0) return false;
    iovec lv{b,l}, rv{(void*)a,l};
    return process_vm_readv(proc::pid,&lv,1,&rv,1,0)==(ssize_t)l;
}
static bool nm_write(uint64_t a, uint32_t v) {
    if (proc::pid<=0||!a) return false;
    iovec lv{&v,4}, rv{(void*)a,4};
    return process_vm_writev(proc::pid,&lv,1,&rv,1,0)==4;
}

struct Region { uint64_t start,end; };

// Анонимные RW регионы — именно там Unity хранит managed heap
static void get_anon_rw(std::vector<Region>& out) {
    out.clear();
    char path[64]; snprintf(path,sizeof path,"/proc/%d/maps",proc::pid);
    FILE* f=fopen(path,"r"); if(!f) return;
    char line[512];
    while(fgets(line,sizeof line,f)) {
        uint64_t s=0,e=0; char perm[8]={};
        if(sscanf(line,"%lx-%lx %7s",&s,&e,perm)!=3) continue;
        if(perm[0]!='r'||perm[1]!='w') continue;
        if(e-s<0x1000||e-s>0x40000000ULL) continue;
        // Анонимный = нет пути в конце строки (либо "[heap]" — тоже берём)
        char* nl=strchr(line,'\n'); if(nl)*nl=0;
        // Находим конец поля permissions
        const char* p=line;
        int sp=0;
        while(*p&&sp<4){if(*p==' ')sp++;p++;}
        // Пропускаем смещение, dev, inode
        // Если после inode нет имени пути — анонимный
        char inode_s[32]={},name[256]={};
        if(sscanf(line,"%*x-%*x %*s %*x %*x:%*x %31s %255[^\n]",inode_s,name)<=0)
            name[0]=0;
        // Принимаем анонимные (name пустой или [heap]/[anon])
        bool anon = (name[0]==0||name[0]=='['||strncmp(name,"[heap",5)==0||
                     strncmp(name,"[anon",5)==0);
        if(anon && s && e>s) out.push_back({s,e});
    }
    fclose(f);
}

static void scan_and_patch() {
    std::vector<Region> regions;
    get_anon_rw(regions);
    static uint8_t buf[131072]; // 128KB chunks
    int found=0;
    for(const auto& r:regions) {
        for(uint64_t a=r.start; a+8<=r.end; a+=sizeof(buf)-NM_STRIDE*4) {
            size_t chunk=(size_t)((r.end-a)<sizeof(buf)?(r.end-a):sizeof(buf));
            if(!nm_read(a,buf,chunk)) continue;
            // Ищем anchor (9) с последующим NM_SEARCH в окне NM_STRIDE DWORD
            for(size_t o=0; o+8<=chunk; o+=4) {
                uint32_t v0; memcpy(&v0,buf+o,4);
                if(v0!=NM_ANCHOR) continue;
                // Проверяем следующие NM_STRIDE DWORD на NM_SEARCH
                for(int k=1;k<=NM_STRIDE && o+k*4+4<=chunk;k++) {
                    uint32_t vk; memcpy(&vk,buf+o+k*4,4);
                    if(vk==NM_SEARCH) {
                        uint64_t target=a+o+(uint64_t)(k*4);
                        if(nm_write(target,NM_PATCH)) {
                            g_bk.push_back({target,NM_SEARCH});
                            found++;
                        }
                        break;
                    }
                }
            }
        }
    }
}

static void restore_all() {
    for(const auto& e:g_bk) nm_write(e.addr,e.orig);
    g_bk.clear();
}

inline void tick() {
    // ── PID change = new match: reset state so patches are not re-applied
    //    on a fresh process that shares no memory with the old one.
    if (proc::pid != g_last_pid) {
        if (g_busy.load()) return;  // wait until in-flight thread finishes
        g_bk.clear();              // old addresses are dead, just drop them
        g_last     = false;        // force re-sync on next tick if still enabled
        g_last_pid = proc::pid;
    }
    bool opt=cfg::nightmode::enabled;
    if(opt==g_last) return;
    if(g_busy.exchange(true)) return;
    bool en=opt;
    std::thread([en](){
        if(en){g_bk.clear();scan_and_patch();}
        else  {restore_all();}
        g_last=en;
        g_busy=false;
    }).detach();
}
inline void run(){ tick(); }
} // namespace night_mode
