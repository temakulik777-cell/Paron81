#pragma once
// ─────────────────────────────────────────────────────────────────────────────
//  world.hpp  —  Potato GFX
//  Порт из world.cpp (intmain12_rework / Neverlose).
//  Адаптирован для leave2 (пути include исправлены).
// ─────────────────────────────────────────────────────────────────────────────
#include <sys/uio.h>
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <thread>
#include <atomic>
#include "../other/memory.hpp"
#include "../protect/oxorany.hpp"
#include "../ui/cfg.hpp"

namespace world {

static inline bool wpm_raw(uint64_t addr, const void* buf, size_t len) {
    if (proc::pid <= 0 || !addr) return false;
    struct iovec lv, rv;
    lv.iov_base = const_cast<void*>(buf);
    lv.iov_len  = len;
    rv.iov_base = reinterpret_cast<void*>(addr);
    rv.iov_len  = len;
    return process_vm_writev(proc::pid, &lv, 1, &rv, 1, 0) == (ssize_t)len;
}

template<typename T>
static inline bool wpm(uint64_t addr, const T& v) { return wpm_raw(addr, &v, sizeof(T)); }

// ═══════════════════════════════════════════════════════════════════════════
//  POTATO GFX
// ═══════════════════════════════════════════════════════════════════════════
namespace potato {

static const uint32_t TEX_SEARCH = 1073741890u; // 0x40000042
static const uint32_t TEX_PATCH  = 1086324736u; // 0x40C00000

struct AddrVal32 { uint64_t addr; uint32_t orig; };
static std::vector<AddrVal32> bk;
static std::atomic<bool> busy{ false };
static bool last_opt = false;

static bool read_chunk(uint64_t addr, void* buf, size_t len) {
    if (proc::pid <= 0) return false;
    struct iovec lv, rv;
    lv.iov_base = buf;
    lv.iov_len  = len;
    rv.iov_base = reinterpret_cast<void*>(addr);
    rv.iov_len  = len;
    return process_vm_readv(proc::pid, &lv, 1, &rv, 1, 0) == (ssize_t)len;
}

struct MemRegion { uint64_t start, end; };

static void get_rw_regions(std::vector<MemRegion>& out) {
    out.clear();
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/maps", proc::pid);
    FILE* f = fopen(path, "r");
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        uint64_t st = 0, en = 0;
        char perm[8] = {0};
        if (sscanf(line, "%lx-%lx %7s", &st, &en, perm) != 3) continue;
        if (perm[0] == 'r' && perm[1] == 'w' && st && en > st && (en - st) >= 0x1000)
            out.push_back({ st, en });
    }
    fclose(f);
}

static void scan_and_patch() {
    std::vector<MemRegion> regions;
    get_rw_regions(regions);
    static uint8_t buf[65536];
    for (const auto& r : regions) {
        for (uint64_t a = r.start; a + 4 <= r.end; a += sizeof(buf)) {
            size_t len = (size_t)((r.end - a) < sizeof(buf) ? (r.end - a) : sizeof(buf));
            if (!read_chunk(a, buf, len)) continue;
            for (size_t o = 0; o + 4 <= len; o += 4) {
                uint32_t v; memcpy(&v, buf + o, 4);
                if (v == TEX_SEARCH) {
                    uint64_t addr = a + o;
                    if (wpm<uint32_t>(addr, TEX_PATCH))
                        bk.push_back({ addr, v });
                }
            }
        }
    }
}

static void restore_all() {
    for (const auto& e : bk)
        wpm<uint32_t>(e.addr, e.orig);
    bk.clear();
}

static void tick() {
    bool opt = cfg::world::potato;
    if (opt == last_opt) return;
    if (busy.exchange(true)) return;
    bool enable = opt;
    std::thread([enable]() {
        if (enable) { bk.clear(); scan_and_patch(); }
        else        { restore_all(); }
        last_opt = enable;
        busy = false;
    }).detach();
}

} // namespace potato

inline void run() {
    potato::tick();
}

} // namespace world
