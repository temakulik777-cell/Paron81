#include "ambient_light.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include "../ui/cfg.hpp"
#include <cmath>

/*
 * Ambient Light — ImGui overlay через BackgroundDrawList.
 * Рисует полупрозрачный цветной rect поверх экрана с опциональной пульсацией.
 *
 * Параметры (cfg::ambient):
 *   enabled   — вкл/выкл
 *   color     — ImVec4 RGBA цвет подсветки
 *   intensity — 0.0 .. 1.0  базовая непрозрачность
 *   pulse     — bool  пульсировать или статично
 *   pulse_spd — скорость пульсации (0.5 .. 5.0)
 */

extern float g_sw;
extern float g_sh;

namespace ambient_light {

void run() {
    if (!cfg::ambient::enabled) return;

    ImDrawList* bg = ImGui::GetBackgroundDrawList();
    if (!bg) return;

    float base_alpha  = cfg::ambient::intensity;
    float final_alpha = base_alpha;

    if (cfg::ambient::pulse) {
        float t   = static_cast<float>(ImGui::GetTime());
        float spd = cfg::ambient::pulse_spd;
        float wave = (sinf(t * spd) + 1.f) * 0.5f;
        // sine mapped to [0.4 .. 1.0] — не гасим в ноль
        float lo  = 0.4f, hi = 1.0f;
        float mod = lo + wave * (hi - lo);
        final_alpha = base_alpha * mod;
    }

    if (final_alpha > 0.85f) final_alpha = 0.85f;
    if (final_alpha < 0.f)   final_alpha = 0.f;

    const ImVec4& c = cfg::ambient::color;
    ImU32 col = IM_COL32(
        static_cast<int>(c.x * 255.f),
        static_cast<int>(c.y * 255.f),
        static_cast<int>(c.z * 255.f),
        static_cast<int>(final_alpha * 255.f)
    );

    bg->AddRectFilled(ImVec2(0.f, 0.f), ImVec2(g_sw, g_sh), col);
}

} // namespace ambient_light
