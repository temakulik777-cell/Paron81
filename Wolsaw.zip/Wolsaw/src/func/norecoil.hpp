#pragma once
// ─────────────────────────────────────────────────────────────────────────────
//  norecoil.hpp  —  No Recoil / No Spread / Rapid Fire
//
//  ВАЖНО: оригинальный norecoil.h использовал смещения из другого движка
//  (disc::NRK + WeaponContext с полями +0x30/+0x38/+0x40/+0x68/+0x78/+0x7C).
//  В leave2 live-layout отличается: комментарий в player.hpp подтверждает
//  что part+0x30 (WeaponContext INLINE) существует в dump.cs, но не в live
//  билде. Запись по неверным смещениям приводила к краш у.
//
//  Текущее состояние: тики безопасны (нет записи в память), все cfg-флаги
//  работают (меню показывает тоглы), но фактический эффект пока отсутствует.
//  Для активации нужно задампить live WeaponContext и уточнить смещения.
// ─────────────────────────────────────────────────────────────────────────────
#include "../ui/cfg.hpp"

namespace norecoil {

// Безопасный stub — не пишет в память, не крашит.
// Оставляем в cfg::weapon флаги для меню, эффект будет добавлен после дампа.
inline void tick(uint64_t /*local_player*/) noexcept {
    // TODO: дамп live WeaponContext смещений для этого билда.
    // Известно из player.hpp:
    //   part + 0x40 = UnityEngine.Transform (HitTransform)
    //   part + 0x78 = qjf (ActiveWeapon)
    //   part + 0x88 = packed scalars
    //   part + 0xC8 = ClearWeaponSignal
    // WeaponContext (dump.cs: part+0x30) в live layout отсутствует.
    (void)cfg::weapon::norecoil;
    (void)cfg::weapon::nospread;
    (void)cfg::weapon::rapidfire;
}

inline void restore() noexcept {}

} // namespace norecoil
