#pragma once

#include "imgui.h"

namespace visuals {
    void draw();
    // Live debug: local player's held-weapon readout for the overlay.
    inline uint64_t g_local = 0;
    inline uint8_t g_local_wid = 0;
    inline char g_local_wname[32]{};
    void dbox(const ImVec2& t, const ImVec2& b, float a, ImU32 override_col = 0);
    void dhp(int hp, const ImVec2& t, const ImVec2& b, float box_h, float a);
    void dnick(const char* name, const ImVec2& box_max, float cx, float sz, float a);
    void dweapon(const char* weapon, float x, float y, float sz, float a);
    void dwicon(char icon, float x, float y, float sz, float a);
    void ddist(float dist, float x, float y, float sz, float a);
    void draw_text_outlined(ImDrawList* dl, ImFont* font, float size, const ImVec2& pos, ImU32 color, const char* text);
}
