#pragma once
// ─────────────────────────────────────────────────────────────────────────────
//  bullet_tracer.hpp  —  2D + 3D Bullet Tracers
//  cfg::tracer::mode:
//    0 = 2D (экранная линия origin→impact с fade+spark)
//    1 = 3D (линия в мировом пространстве, projected каждый кадр)
//         Трейс живёт как 3D-отрезок, рисуется через W2S каждый кадр
//         → сохраняет перспективу при движении камеры
// ─────────────────────────────────────────────────────────────────────────────
#include "imgui.h"
#include "../game/math.hpp"
#include "../other/vector3.h"
#include "../ui/cfg.hpp"
#include <cmath>

extern float g_sw;
extern float g_sh;

namespace bullet_tracer {

static constexpr int MAX_T = 96;

struct Trace {
    Vector3 origin, impact;
    double  spawn;
    bool    alive;
};
static Trace g_buf[MAX_T];
static int   g_head = 0;

inline void push(const Vector3& o, const Vector3& i) {
    if(!cfg::tracer::enabled) return;
    Trace& t=g_buf[g_head%MAX_T];
    t={o,i,ImGui::GetTime(),true};
    g_head=(g_head+1)%MAX_T;
}

static inline float clampf(float v,float lo,float hi){
    return v<lo?lo:(v>hi?hi:v);
}
static inline ImVec2 lerp2(ImVec2 a,ImVec2 b,float t){
    return {a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t};
}

inline void draw(ImDrawList* dl, const matrix& view, const matrix& proj) {
    if(!cfg::tracer::enabled||!dl) return;
    const double now=ImGui::GetTime();
    const float  life=cfg::tracer::lifetime;
    const float  th  =cfg::tracer::thickness;
    const ImVec4 col4=cfg::tracer::color;
    const bool   spark=cfg::tracer::spark;
    const bool   fade =cfg::tracer::fade;
    const int    mode =cfg::tracer::mode; // 0=2D 1=3D

    for(int i=0;i<MAX_T;i++){
        Trace& t=g_buf[i];
        if(!t.alive) continue;
        float age=(float)(now-t.spawn);
        if(age>=life){t.alive=false;continue;}
        float alpha=fade?(1.f-age/life):1.f;
        alpha=clampf(alpha,0.f,1.f);

        ImVec2 s_o, s_i;
        bool ok_o=world_to_screen(t.origin,view,proj,s_o);
        bool ok_i=world_to_screen(t.impact,view,proj,s_i);
        if(!ok_o) s_o={g_sw*0.5f,g_sh}; // fallback: bottom-center
        if(!ok_i) continue;

        auto mk_col=[&](float alpha_mul,float r_mul=1.f,float g_mul=1.f,float b_mul=1.f)->ImU32{
            return IM_COL32((int)(col4.x*r_mul*255),(int)(col4.y*g_mul*255),
                            (int)(col4.z*b_mul*255),(int)(col4.w*alpha*alpha_mul*255));
        };

        // ── 2D / 3D общая линия ───────────────────────────────────────────
        if(mode==0) {
            // ── 2D классический ──────────────────────────────────────────
            // Shadow
            dl->AddLine(s_o,s_i,IM_COL32(0,0,0,(int)(alpha*0.4f*255)),th+1.5f);
            // Main line gradient: fade from dim at origin to bright at impact
            dl->AddLine(s_o,s_i,mk_col(0.5f),th*0.5f);
            dl->AddLine(s_o,s_i,mk_col(1.f),th);
            // Moving head dot
            {
                float t_prog=clampf(1.f-age/life*0.8f,0.f,1.f);
                ImVec2 head=lerp2(s_o,s_i,t_prog);
                dl->AddCircleFilled(head,th*1.2f,IM_COL32(255,255,230,(int)(alpha*220)),8);
            }
        } else {
            // ── 3D перспективный: разбиваем на N сегментов ───────────────
            // Интерполируем мировую позицию и проецируем каждую точку
            const int SEG=12;
            ImVec2 prev_sp; bool prev_ok=false;
            for(int s=0;s<=SEG;s++){
                float frac=(float)s/(float)SEG;
                Vector3 wp{
                    t.origin.x+(t.impact.x-t.origin.x)*frac,
                    t.origin.y+(t.impact.y-t.origin.y)*frac,
                    t.origin.z+(t.impact.z-t.origin.z)*frac
                };
                ImVec2 sp; bool ok=world_to_screen(wp,view,proj,sp);
                if(ok && prev_ok) {
                    float seg_alpha=alpha*(0.3f+0.7f*frac); // ярче к импакту
                    ImU32 lc=IM_COL32((int)(col4.x*255),(int)(col4.y*255),
                                      (int)(col4.z*255),(int)(seg_alpha*col4.w*255));
                    ImU32 sc=IM_COL32(0,0,0,(int)(seg_alpha*0.35f*255));
                    dl->AddLine(prev_sp,sp,sc,th+1.5f);
                    dl->AddLine(prev_sp,sp,lc,th);
                }
                prev_sp=sp; prev_ok=ok;
            }
            // Glow gradient tube эффект — широкая прозрачная линия
            {
                ImU32 gc=IM_COL32((int)(col4.x*255),(int)(col4.y*255),
                                  (int)(col4.z*255),(int)(alpha*col4.w*0.18f*255));
                ImVec2 sp0,sp1;
                if(world_to_screen(t.origin,view,proj,sp0)&&
                   world_to_screen(t.impact,view,proj,sp1))
                    dl->AddLine(sp0,sp1,gc,th*4.f);
            }
        }

        // ── Spark ──────────────────────────────────────────────────────────
        if(spark) {
            float sr=clampf(th*3.f*(1.f-age/life),1.f,8.f);
            // Core
            dl->AddCircleFilled(s_i,sr*0.5f,IM_COL32(255,255,255,(int)(alpha*220)),8);
            // Halo
            dl->AddCircle(s_i,sr,mk_col(0.7f),12,1.2f);
            // 4 short rays
            static const ImVec2 dirs[4]={{1,0},{0,1},{-1,0},{0,-1}};
            for(auto& d:dirs) {
                float rlen=sr*2.5f;
                dl->AddLine(s_i,{s_i.x+d.x*rlen,s_i.y+d.y*rlen},mk_col(0.5f),0.9f);
            }
        }
    }
}

} // namespace bullet_tracer
