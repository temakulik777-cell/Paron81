#pragma once
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <cstdint>
#include <cstring>
#include "hitsounds_data.h"

namespace hitsounds {
static SLObjectItf engineObject = nullptr;
static SLEngineItf engine = nullptr;
static SLObjectItf mixObject = nullptr;
static SLObjectItf playerObject = nullptr;
static SLPlayItf playItf = nullptr;
static SLAndroidSimpleBufferQueueItf queueItf = nullptr;
static unsigned char pcm[90000];
static SLuint32 pcmSize = 0;
static bool init() {
    if (engine) return true;
    if (slCreateEngine(&engineObject, 0, nullptr, 0, nullptr, nullptr) != SL_RESULT_SUCCESS) return false;
    if ((*engineObject)->Realize(engineObject, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) return false;
    if ((*engineObject)->GetInterface(engineObject, SL_IID_ENGINE, &engine) != SL_RESULT_SUCCESS) return false;
    if ((*engine)->CreateOutputMix(engine, &mixObject, 0, nullptr, nullptr) != SL_RESULT_SUCCESS) return false;
    if ((*mixObject)->Realize(mixObject, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) return false;
    return true;
}
static void play(const unsigned char* wav, unsigned int size) {
    if (!wav || size < 44 || !init()) return;
    // Locate the WAV data chunk instead of assuming a fixed 44-byte header.
    unsigned int off = 12, dataOff = 0, dataLen = 0;
    while (off + 8 <= size) {
        uint32_t len = (uint32_t)wav[off+4] | ((uint32_t)wav[off+5]<<8) | ((uint32_t)wav[off+6]<<16) | ((uint32_t)wav[off+7]<<24);
        if (!memcmp(wav+off, "data", 4)) { dataOff = off + 8; dataLen = len; break; }
        if (len > size - off - 8) break;
        off += 8 + len + (len & 1u);
    }
    if (!dataOff || !dataLen || dataOff + dataLen > size || dataLen > sizeof(pcm)) return;
    // Supplied assets are PCM WAV; copy sample bytes to a stable queue buffer.
    memcpy(pcm, wav + dataOff, dataLen); pcmSize = dataLen;
    if (playerObject) { (*playerObject)->Destroy(playerObject); playerObject=nullptr; playItf=nullptr; queueItf=nullptr; }
    SLDataLocator_AndroidSimpleBufferQueue locBufq = {SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE, 1};
    SLDataFormat_PCM format = {SL_DATAFORMAT_PCM, 1, SL_SAMPLINGRATE_44_1, SL_PCMSAMPLEFORMAT_FIXED_16, SL_PCMSAMPLEFORMAT_FIXED_16, SL_SPEAKER_FRONT_CENTER, SL_BYTEORDER_LITTLEENDIAN};
    SLDataSource audioSrc = {&locBufq, &format};
    SLDataLocator_OutputMix locOut = {SL_DATALOCATOR_OUTPUTMIX, mixObject};
    SLDataSink audioSnk = {&locOut, nullptr};
    const SLInterfaceID ids[] = {SL_IID_ANDROIDSIMPLEBUFFERQUEUE}; const SLboolean req[] = {SL_BOOLEAN_TRUE};
    if ((*engine)->CreateAudioPlayer(engine, &playerObject, &audioSrc, &audioSnk, 1, ids, req) != SL_RESULT_SUCCESS) { playerObject=nullptr; return; }
    if ((*playerObject)->Realize(playerObject, SL_BOOLEAN_FALSE) != SL_RESULT_SUCCESS) { (*playerObject)->Destroy(playerObject); playerObject=nullptr; return; }
    (*playerObject)->GetInterface(playerObject, SL_IID_PLAY, &playItf);
    (*playerObject)->GetInterface(playerObject, SL_IID_ANDROIDSIMPLEBUFFERQUEUE, &queueItf);
    if (playItf && queueItf) { (*playItf)->SetPlayState(playItf, SL_PLAYSTATE_STOPPED); (*queueItf)->Clear(queueItf); (*queueItf)->Enqueue(queueItf, pcm, pcmSize); (*playItf)->SetPlayState(playItf, SL_PLAYSTATE_PLAYING); }
}
inline void on_hit(int type) {
    // The supplied hit.wav is valid PCM WAV. The other embedded samples are
    // MP3 streams (ID3 headers), which OpenSL ES buffer-queue PCM cannot decode.
    // Until an MP3 decoder is added, use the valid WAV for all selector values.
    (void)type;
    play(g_snd_hit_data, g_snd_hit_size);
}
} // namespace hitsounds
