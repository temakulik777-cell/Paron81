#pragma once
// ════════════════════════════════════════════════════════════════════════════
//  sku_color.hpp  —  Character material color (Chams) via process memory
//
//  Цепочка объектов (из dump.cs):
//
//    gby (TypeDefIndex 14216)  — основной рендерер персонажа
//      +0x50  →  vub*  akil
//
//    vub (TypeDefIndex 14207)
//      +0x10  →  SkinnedMeshRenderer*  ngqa
//      +0x18  →  Material*            mmyt  (visible)
//      +0x20  →  Material*            lthm  (through-wall / occluded)
//
//    UnityEngine.Object  (TypeDefIndex 8348)
//      +0x10  →  IntPtr  m_CachedPtr  (→ native C++ object)
//
//    Native Unity Material (Unity 2021 BIRP/URP, ARM64):
//      UnityPropertySheet для _Color (k_ColorId = Shader.PropertyToID("_Color"))
//      располагается по offset +0x48 от начала нативного объекта.
//      (подтверждено на Standoff 2 external cheats, Unity 2021.3.x)
//      Данные: float r, g, b, a  (16 байт, формат Color RGBA)
//
//    Material.SetColorImpl_Injected RVA: 0x7606F4C  (static, не вызываем
//    из external process, используем прямую запись в нативный буфер)
//
// ════════════════════════════════════════════════════════════════════════════

#include "../game/game.hpp"
#include "../game/player.hpp"
#include "../ui/cfg.hpp"        // cfg::chams::* определены здесь
#include <unordered_map>
#include <vector>
#include <cstdint>

namespace sku_color {

// ── Структура цвета (Unity Color = float r,g,b,a) ─────────────────────────
struct Color4 { float r, g, b, a; };

// ── Кеш материалов на игрока ──────────────────────────────────────────────
struct ChamsMats {
    uint64_t mat_vis  = 0;   // managed ptr: vub->mmyt
    uint64_t mat_occ  = 0;   // managed ptr: vub->lthm
    uint64_t nat_vis  = 0;   // нативный ptr для mat_vis
    uint64_t nat_occ  = 0;   // нативный ptr для mat_occ
    long long ts      = 0;   // время последнего обновления (мс)
};
static std::unordered_map<uint64_t, ChamsMats> g_cache;
static long long g_last_gc = 0;

// ── Смещения ──────────────────────────────────────────────────────────────
static constexpr uint64_t OFF_GBY_AKIL        = 0x50; // gby::akil  (vub*)
static constexpr uint64_t OFF_VUB_MMYT        = 0x18; // vub::mmyt  (Material* visible)
static constexpr uint64_t OFF_VUB_LTHM        = 0x20; // vub::lthm  (Material* occluded)
static constexpr uint64_t OFF_UNITY_CACHED    = 0x10; // UnityObject::m_CachedPtr
static constexpr uint64_t OFF_NATIVE_COLOR_A  = 0x48; // native Material: _Color RGBA (primary)
static constexpr uint64_t OFF_NATIVE_COLOR_B  = 0x50; // native Material: _Color RGBA (fallback)

// ── Проверка значений float RGBA ──────────────────────────────────────────
static inline bool color_valid(const Color4& c) noexcept {
    // Допустим чуть за [0,1] из-за HDR, но нас интересует стандартный диапазон
    auto f = [](float v){ return v >= -0.01f && v <= 2.f; };
    return f(c.r) && f(c.g) && f(c.b) && f(c.a);
}

// ── Разрешить нативный ptr из managed Material ────────────────────────────
static uint64_t resolve_native(uint64_t managed) noexcept {
    if (!obj_ptr(managed)) return 0;
    const uint64_t nat = rpm<uint64_t>(managed + OFF_UNITY_CACHED);
    return obj_ptr(nat) ? nat : 0;
}

// ── Найти правильное смещение _Color внутри нативного Material ────────────
//   Пробуем +0x48 и +0x50. Валидное — то, которое содержит правдоподобные float.
//   Возвращает реальное смещение или 0 если не нашли.
static uint64_t find_color_offset(uint64_t native_mat) noexcept {
    if (!native_mat) return 0;
    Color4 probe{};
    if (mem_read(native_mat + OFF_NATIVE_COLOR_A, &probe, sizeof(probe)) && color_valid(probe))
        return OFF_NATIVE_COLOR_A;
    if (mem_read(native_mat + OFF_NATIVE_COLOR_B, &probe, sizeof(probe)) && color_valid(probe))
        return OFF_NATIVE_COLOR_B;
    // Ещё одна попытка: некоторые билды Standoff 2 используют +0x40
    if (mem_read(native_mat + 0x40, &probe, sizeof(probe)) && color_valid(probe))
        return 0x40;
    return OFF_NATIVE_COLOR_A; // крайний fallback — пишем по primary
}

// ── Записать Color4 в нативный Material ───────────────────────────────────
static bool write_color(uint64_t native_mat, const Color4& col) noexcept {
    if (!native_mat) return false;
    const uint64_t off = find_color_offset(native_mat);
    return wpm<Color4>(native_mat + off, col);
}

// ── Найти gby компонент в parts list игрока ───────────────────────────────
static uint64_t find_gby(uint64_t player) noexcept {
    if (!player || !obj_ptr(player)) return 0;
    const uint64_t model_class = rpm<uint64_t>(proc::lib + v100::model_typeinfo);
    if (!model_class) return 0;

    const uint64_t container = rpm<uint64_t>(player + v100::player_parts);
    const uint64_t list      = rpm<uint64_t>(container + v100::parts_list);
    const int      count     = rpm<int>(list + v100::list_count);
    const uint64_t array     = rpm<uint64_t>(list + v100::list_items);
    const uint64_t length    = rpm<uint64_t>(array + v100::array_length);

    if (!plausible(container) || !plausible(list) || !plausible(array) ||
        count <= 0 || count > 64 || length < (uint64_t)count || length > 256)
        return 0;

    for (int i = 0; i < count; ++i) {
        const uint64_t part = rpm<uint64_t>(array + v100::array_data + (uint64_t)i * 8);
        if (!obj_ptr(part)) continue;
        if (exact_class(part, model_class)) {
            // Проверяем что akil (vub) валиден
            const uint64_t akil = rpm<uint64_t>(part + OFF_GBY_AKIL);
            if (obj_ptr(akil)) return part;
        }
    }

    // Fallback: сканируем поля самого player объекта как массивы компонент
    for (uint64_t field = 0x10; field <= 0x38; field += 8) {
        const uint64_t arr = rpm<uint64_t>(player + field);
        if (!plausible(arr)) continue;
        const uint64_t cnt = rpm<uint64_t>(arr + v100::array_length);
        if (cnt == 0 || cnt > 256) continue;
        for (uint64_t j = 0; j < cnt; ++j) {
            const uint64_t comp = rpm<uint64_t>(arr + v100::array_data + j * 8);
            if (!obj_ptr(comp)) continue;
            if (exact_class(comp, model_class)) {
                const uint64_t akil = rpm<uint64_t>(comp + OFF_GBY_AKIL);
                if (obj_ptr(akil)) return comp;
            }
        }
    }
    return 0;
}

// ── Заполнить ChamsMats для игрока ────────────────────────────────────────
static bool refresh_mats(uint64_t player, ChamsMats& out) noexcept {
    const uint64_t gby = find_gby(player);
    if (!gby) return false;

    const uint64_t akil    = rpm<uint64_t>(gby + OFF_GBY_AKIL);
    const uint64_t mat_vis = rpm<uint64_t>(akil + OFF_VUB_MMYT);
    const uint64_t mat_occ = rpm<uint64_t>(akil + OFF_VUB_LTHM);

    if (!obj_ptr(mat_vis) && !obj_ptr(mat_occ)) return false;

    out.mat_vis = mat_vis;
    out.mat_occ = mat_occ;
    out.nat_vis = resolve_native(mat_vis);
    out.nat_occ = resolve_native(mat_occ);
    out.ts      = diag::now_ms();
    return true;
}

// ── Публичный API ─────────────────────────────────────────────────────────

// Применить chams к одному игроку (вызывается каждый кадр)
static void apply(uint64_t player, bool is_local) noexcept {
    if (!cfg::chams::enabled) return;
    if (is_local && !cfg::chams::apply_to_local) return;
    if (!obj_ptr(player)) return;

    const long long now = diag::now_ms();

    // GC кеша раз в 15 секунд
    if (now - g_last_gc > 15000) {
        g_cache.clear();
        g_last_gc = now;
    }

    ChamsMats& entry = g_cache[player];

    // Обновляем кеш раз в 3 секунды (материал может смениться при смене скина)
    if (!entry.mat_vis || now - entry.ts > 3000) {
        if (!refresh_mats(player, entry)) return;
    }

    const float alpha = (float)cfg::chams::opacity / 100.f;

    // Цвет видимой части
    if (entry.nat_vis) {
        const ImVec4& c = cfg::chams::color_visible;
        write_color(entry.nat_vis, { c.x, c.y, c.z, alpha });
    }

    // Цвет сквозь стены
    if (cfg::chams::walls && entry.nat_occ) {
        const ImVec4& cw = cfg::chams::color_wall;
        write_color(entry.nat_occ, { cw.x, cw.y, cw.z, alpha * 0.65f });
    }
}

// Сбросить конкретного игрока (восстановить белый)
static void reset(uint64_t player) noexcept {
    auto it = g_cache.find(player);
    if (it == g_cache.end()) return;
    const Color4 white = { 1.f, 1.f, 1.f, 1.f };
    if (it->second.nat_vis) write_color(it->second.nat_vis, white);
    if (it->second.nat_occ) write_color(it->second.nat_occ, white);
    g_cache.erase(it);
}

// Сбросить всех (при выключении фичи или смене карты)
static void reset_all() noexcept {
    const Color4 white = { 1.f, 1.f, 1.f, 1.f };
    for (auto& [_, m] : g_cache) {
        if (m.nat_vis) write_color(m.nat_vis, white);
        if (m.nat_occ) write_color(m.nat_occ, white);
    }
    g_cache.clear();
}

} // namespace sku_color
