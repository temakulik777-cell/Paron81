#pragma once
// ─────────────────────────────────────────────────────────────────────────────
//  effects.hpp  —  Визуальные эффекты
//    • rain()         — дождь (капли на экране)
//    • particles()    — хитовые частицы (spawn_hit)
//    • death_effect() — эффект смерти врага (spawn_death)
//  Вызов: effects::tick(dl) каждый кадр в post-frame
//         effects::spawn_hit(sx, sy) при HP-дропе
//         effects::spawn_death(sx, sy) при Health==1 или смерти
// ─────────────────────────────────────────────────────────────────────────────
#include "imgui.h"
#include "../ui/cfg.hpp"
#include <vector>
#include <cmath>
#include <cstdlib>
#include <algorithm>

extern float g_sw;
extern float g_sh;

namespace effects {

// ── Rng ───────────────────────────────────────────────────────────────────────
static inline float randf(float lo=0.f, float hi=1.f) {
    return lo+(hi-lo)*((float)(rand()&0x7FFF)/32767.f);
}

// ─────────────────────────────────────────────────────────────────────────────
//  RAIN
// ─────────────────────────────────────────────────────────────────────────────
struct Drop {
    float x,y,vx,vy,len,alpha;
};
static Drop   g_drops[256];
static bool   g_drops_init = false;
static double g_rain_t     = 0.0;

static void rain_init() {
    for(auto& d:g_drops) {
        d.x     = randf(0.f,1.f);
        d.y     = randf(-0.3f,1.f);
        d.vx    = randf(-0.01f,0.f);
        d.vy    = randf(0.35f,0.7f);
        d.len   = randf(0.012f,0.028f);
        d.alpha = randf(0.25f,0.65f);
    }
    g_drops_init=true;
}

static void draw_rain(ImDrawList* dl, float dt) {
    if(!cfg::misc::rain) return;
    if(!g_drops_init) rain_init();
    for(auto& d:g_drops) {
        d.x += d.vx*dt;
        d.y += d.vy*dt;
        if(d.y>1.1f){
            d.x=randf(0.f,1.f);
            d.y=randf(-0.15f,0.f);
        }
        float sx0=d.x*g_sw,        sy0=d.y*g_sh;
        float sx1=sx0+d.vx*d.len*g_sw, sy1=sy0+d.vy*d.len*g_sh;
        ImU32 c=IM_COL32(180,210,255,(int)(d.alpha*cfg::misc::rain_opacity*255));
        dl->AddLine({sx0,sy0},{sx1,sy1},c,1.f);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  HIT PARTICLES
// ─────────────────────────────────────────────────────────────────────────────
struct Particle {
    float x,y,vx,vy,life,max_life,size;
    ImU32 color;
    bool  active;
};
static Particle g_parts[256];
static int      g_part_head=0;

static void emit_particle(float x,float y,ImU32 col,
                           float vx,float vy,float life,float size){
    auto& p=g_parts[g_part_head%256];
    p={x,y,vx,vy,life,life,size,col,true};
    g_part_head++;
}

void spawn_hit(float sx, float sy) {
    if (!cfg::effects::hit_particles) return;
    // Кровавые брызги: мелкие красные/оранжевые частицы
    int count=12;
    for(int i=0;i<count;i++){
        float angle=randf(0.f,6.2831f);
        float spd=randf(30.f,120.f);
        float vx=cosf(angle)*spd, vy=sinf(angle)*spd*0.6f;
        // цвет: от ярко-красного к тёмно-красному
        int r=200+rand()%55, g_c=rand()%40, b=rand()%20;
        ImU32 col=IM_COL32(r,g_c,b,230);
        emit_particle(sx,sy,col,vx,vy,randf(0.12f,0.35f),randf(2.f,5.f));
    }
    // Пара жёлтых "искр"
    for(int i=0;i<3;i++){
        float angle=randf(0.f,6.2831f);
        float spd=randf(80.f,180.f);
        emit_particle(sx,sy,IM_COL32(255,220,60,255),
            cosf(angle)*spd,sinf(angle)*spd*0.5f,randf(0.06f,0.18f),randf(1.5f,3.f));
    }
}

void spawn_death(float sx, float sy) {
    if (!cfg::effects::death_effect) return;
    // Крупный взрыв: много частиц разных цветов
    for(int i=0;i<32;i++){
        float angle=randf(0.f,6.2831f);
        float spd=randf(60.f,200.f);
        float vx=cosf(angle)*spd, vy=sinf(angle)*spd*0.55f - randf(20.f,60.f);
        int r=100+rand()%155, g_c=rand()%80, b=rand()%30;
        if(i%5==0){r=255;g_c=180;b=30;} // жёлтые
        emit_particle(sx,sy,IM_COL32(r,g_c,b,255),vx,vy,randf(0.3f,0.8f),randf(3.f,8.f));
    }
    // Белые/серые "облака"
    for(int i=0;i<8;i++){
        float angle=randf(0.f,6.2831f);
        float spd=randf(20.f,80.f);
        int gr=150+rand()%100;
        emit_particle(sx,sy,IM_COL32(gr,gr,gr,180),
            cosf(angle)*spd,sinf(angle)*spd,randf(0.4f,1.0f),randf(6.f,14.f));
    }
}

static void draw_particles(ImDrawList* dl, float dt) {
    for(auto& p:g_parts) {
        if(!p.active) continue;
        p.life-=dt;
        if(p.life<=0.f){p.active=false;continue;}
        float t=p.life/p.max_life;
        float alpha=t*t; // квадратичное затухание
        // Гравитация
        p.vy+=200.f*dt;
        p.x+=p.vx*dt;
        p.y+=p.vy*dt;
        // Цвет с alpha
        ImVec4 cv=ImGui::ColorConvertU32ToFloat4(p.color);
        ImU32 c=IM_COL32((int)(cv.x*255),(int)(cv.y*255),(int)(cv.z*255),(int)(alpha*cv.w*255));
        float r=p.size*t;
        if(r>0.5f) dl->AddCircleFilled({p.x,p.y},r,c,8);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  DEATH RING EFFECT (расходящийся круг)
// ─────────────────────────────────────────────────────────────────────────────
struct DeathRing { float x,y,r,max_r,t,life; ImU32 col; };
static DeathRing g_rings[16];
static int       g_ring_head=0;

void spawn_death_ring(float sx,float sy) {
    if (!cfg::effects::death_ring) return;
    auto& r=g_rings[g_ring_head%16];
    r={sx,sy,0.f,80.f,0.f,0.5f,IM_COL32(255,80,20,200)};
    g_ring_head++;
    // Второй контурный круг
    auto& r2=g_rings[(g_ring_head)%16];
    r2={sx,sy,0.f,120.f,0.f,0.7f,IM_COL32(255,200,20,140)};
    g_ring_head++;
}

static void draw_rings(ImDrawList* dl, float dt) {
    for(auto& r:g_rings) {
        if(r.t>=r.life) continue;
        r.t+=dt;
        float prog=r.t/r.life;
        r.r=r.max_r*prog;
        float a=1.f-prog;
        ImVec4 cv=ImGui::ColorConvertU32ToFloat4(r.col);
        ImU32 c=IM_COL32((int)(cv.x*255),(int)(cv.y*255),(int)(cv.z*255),(int)(a*cv.w*255));
        dl->AddCircle({r.x,r.y},r.r,c,32,2.5f*(1.f-prog*0.7f));
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN TICK
// ─────────────────────────────────────────────────────────────────────────────
void tick(ImDrawList* dl, float dt) {
    draw_rain(dl,dt);
    draw_particles(dl,dt);
    draw_rings(dl,dt);
}

} // namespace effects

