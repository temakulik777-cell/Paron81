#pragma once
// ─────────────────────────────────────────────────────────────────────────────
//  radar.hpp  —  Mini Radar (два режима)
//  cfg::radar::style:
//    0 = Round  — классический круглый радар
//    1 = Square — квадратный тактический
//    2 = Arrow  — минималистичный стрелочный (направленный)
// ─────────────────────────────────────────────────────────────────────────────
#include "imgui.h"
#include "../ui/cfg.hpp"
#include <cmath>
#include <algorithm>

extern float g_sw;
extern float g_sh;

namespace radar {

struct Dot { float rx,ry; int hp; float dist; };
static Dot g_dots[64];
static int g_cnt=0;

inline void push(float dx,float dz,int hp) {
    if(!cfg::radar::enabled) return;
    if(g_cnt>=64) return;
    g_dots[g_cnt++]={dx,dz,hp,sqrtf(dx*dx+dz*dz)};
}

static inline ImU32 dot_color(const Dot& d) {
    if(cfg::radar::show_dist) {
        float t=d.dist/cfg::radar::range;
        t=t>1.f?1.f:t;
        return IM_COL32((int)((1.f-t)*255),(int)((1.f-t*0.4f)*180),(int)(t*200),240);
    }
    float ht=(float)d.hp/100.f;
    int r=d.hp<50?255:(int)((1.f-(ht-.5f)*2.f)*255);
    int g=d.hp>50?255:(int)(ht*2.f*255);
    return IM_COL32(r,g,0,240);
}

// ── Round radar ────────────────────────────────────────────────────────────
static void draw_round(ImDrawList* dl,ImVec2 center,float half,float rng) {
    // Фон
    dl->AddCircleFilled(center,half,IM_COL32(10,12,18,210),64);
    dl->AddCircle(center,half,IM_COL32(60,65,85,220),64,1.4f);
    // Кольца
    dl->AddCircle(center,half*0.33f,IM_COL32(255,255,255,12),48,1.f);
    dl->AddCircle(center,half*0.66f,IM_COL32(255,255,255,12),48,1.f);
    // Крест
    dl->AddLine({center.x,center.y-half+5},{center.x,center.y+half-5},
        IM_COL32(255,255,255,10),1.f);
    dl->AddLine({center.x-half+5,center.y},{center.x+half-5,center.y},
        IM_COL32(255,255,255,10),1.f);
    // Clip внутри круга
    dl->PushClipRect({center.x-half,center.y-half},
                     {center.x+half,center.y+half},true);
    // Враги
    for(int i=0;i<g_cnt;i++) {
        float px=center.x+(g_dots[i].rx/rng)*half;
        float py=center.y+(g_dots[i].ry/rng)*half;
        // Зажим в круг
        float ddx=px-center.x,ddy=py-center.y;
        float dd=sqrtf(ddx*ddx+ddy*ddy);
        float rim=half-5.f;
        if(dd>rim){float sc=rim/dd;px=center.x+ddx*sc;py=center.y+ddy*sc;}
        ImU32 c=dot_color(g_dots[i]);
        dl->AddCircleFilled({px,py},4.5f,IM_COL32(0,0,0,160),8);
        dl->AddCircleFilled({px,py},3.2f,c,8);
        // Glow
        ImVec4 cv=ImGui::ColorConvertU32ToFloat4(c);
        dl->AddCircleFilled({px,py},6.f,IM_COL32((int)(cv.x*255),(int)(cv.y*255),(int)(cv.z*255),40),12);
    }
    dl->PopClipRect();
    // Локальный игрок
    float ta=5.5f;
    dl->AddTriangleFilled(
        {center.x,center.y-ta},{center.x-ta*.5f,center.y+ta*.5f},{center.x+ta*.5f,center.y+ta*.5f},
        IM_COL32(255,220,60,255));
    // Accent ring у центра
    dl->AddCircle(center,ta+2.f,IM_COL32(255,220,60,60),16,1.f);
}

// ── Square radar ──────────────────────────────────────────────────────────
static void draw_square(ImDrawList* dl,ImVec2 o,float sz,float rng) {
    float half=sz*0.5f;
    ImVec2 center={o.x+half,o.y+half};
    // Фон
    dl->AddRectFilled(o,{o.x+sz,o.y+sz},IM_COL32(10,12,18,210),6.f);
    dl->AddRect(o,{o.x+sz,o.y+sz},IM_COL32(60,65,85,220),6.f,0,1.4f);
    // Grid
    for(int k=1;k<4;k++) {
        float gx=o.x+sz*k/4.f, gy=o.y+sz*k/4.f;
        dl->AddLine({gx,o.y},{gx,o.y+sz},IM_COL32(255,255,255,8),1.f);
        dl->AddLine({o.x,gy},{o.x+sz,gy},IM_COL32(255,255,255,8),1.f);
    }
    // Clip
    dl->PushClipRect(o,{o.x+sz,o.y+sz},true);
    for(int i=0;i<g_cnt;i++) {
        float t=g_dots[i].dist/rng; if(t>1.f)t=1.f;
        float px=center.x+(g_dots[i].rx/rng)*half;
        float py=center.y+(g_dots[i].ry/rng)*half;
        px=px<o.x+4?o.x+4:(px>o.x+sz-4?o.x+sz-4:px);
        py=py<o.y+4?o.y+4:(py>o.y+sz-4?o.y+sz-4:py);
        ImU32 c=dot_color(g_dots[i]);
        // Diamond shape for square radar
        dl->AddQuadFilled(
            {px,py-4.f},{px+4.f,py},{px,py+4.f},{px-4.f,py},c);
        // Border
        ImVec4 cv=ImGui::ColorConvertU32ToFloat4(c);
        dl->AddQuad(
            {px,py-4.5f},{px+4.5f,py},{px,py+4.5f},{px-4.5f,py},
            IM_COL32(0,0,0,120),1.f);
    }
    dl->PopClipRect();
    // Локальный
    dl->AddQuadFilled(
        {center.x,center.y-6},{center.x+6,center.y},
        {center.x,center.y+6},{center.x-6,center.y},
        IM_COL32(255,220,60,255));
    // Distance labels
    float lab_r=half*0.66f;
    char buf[8]; snprintf(buf,sizeof buf,"%dm",(int)(rng*0.66f));
    ImVec2 ts=ImGui::CalcTextSize(buf);
    dl->AddText({center.x-ts.x*0.5f,center.y-lab_r-ts.y},IM_COL32(255,255,255,40),buf);
}


// ── Arrow radar ───────────────────────────────────────────────────────────
// Minimalist directional style: dark bg, dots shown as directional arrows
static void draw_arrow(ImDrawList* dl, ImVec2 o, float sz, float rng) {
    float half = sz * 0.5f;
    ImVec2 center = {o.x + half, o.y + half};

    // Background
    dl->AddRectFilled(o, {o.x+sz, o.y+sz}, IM_COL32(8,10,14,220), sz*0.08f);
    dl->AddRect(o, {o.x+sz, o.y+sz}, IM_COL32(40,200,120,130), sz*0.08f, 0, 1.5f);

    // Center cross (thin, accent-colored)
    dl->AddLine({center.x, center.y - half*0.85f},
                {center.x, center.y + half*0.85f},
                IM_COL32(40,200,120,35), 1.f);
    dl->AddLine({center.x - half*0.85f, center.y},
                {center.x + half*0.85f, center.y},
                IM_COL32(40,200,120,35), 1.f);

    // Range ring
    dl->AddCircle(center, half*0.72f, IM_COL32(40,200,120,20), 48, 1.f);

    // Clip
    dl->PushClipRect(o, {o.x+sz, o.y+sz}, true);
    for (int i = 0; i < g_cnt; i++) {
        float px = center.x + (g_dots[i].rx / rng) * half;
        float py = center.y + (g_dots[i].ry / rng) * half;
        // Clamp to inside
        float ddx = px - center.x, ddy = py - center.y;
        float dd = sqrtf(ddx*ddx + ddy*ddy);
        float rim = half - 6.f;
        if (dd > rim) { float sc = rim/dd; px = center.x+ddx*sc; py = center.y+ddy*sc; }

        ImU32 c = dot_color(g_dots[i]);
        ImVec4 cv = ImGui::ColorConvertU32ToFloat4(c);

        // Arrow shape pointing outward from center
        float ang = atan2f(ddy, ddx);
        float asz = 5.5f;
        ImVec2 tip  = {px + cosf(ang)*asz*1.2f, py + sinf(ang)*asz*1.2f};
        ImVec2 bl   = {px + cosf(ang+2.4f)*asz, py + sinf(ang+2.4f)*asz};
        ImVec2 br   = {px + cosf(ang-2.4f)*asz, py + sinf(ang-2.4f)*asz};
        // Glow
        dl->AddTriangleFilled(tip, bl, br,
            IM_COL32((int)(cv.x*255),(int)(cv.y*255),(int)(cv.z*255), 50));
        // Arrow fill
        dl->AddTriangleFilled(tip, bl, br, c);
        // Arrow outline
        dl->AddTriangle(tip, bl, br, IM_COL32(0,0,0,100), 1.f);
    }
    dl->PopClipRect();

    // Local player: bright green filled circle with cross
    dl->AddCircleFilled(center, 4.f, IM_COL32(40,220,120,255), 16);
    dl->AddCircle(center, 5.5f, IM_COL32(40,220,120,120), 16, 1.f);
    dl->AddLine({center.x-3.f, center.y},{center.x+3.f,center.y}, IM_COL32(0,0,0,180), 1.f);
    dl->AddLine({center.x, center.y-3.f},{center.x,center.y+3.f}, IM_COL32(0,0,0,180), 1.f);
}

inline void draw(ImDrawList* dl) {
    if(!cfg::radar::enabled||!dl){g_cnt=0;return;}
    float sz  =cfg::radar::size;
    float rng =cfg::radar::range;
    float ox  =g_sw-sz-cfg::radar::pos_x;
    float oy  =g_sh-sz-cfg::radar::pos_y;
    if(cfg::radar::style==0)
        draw_round(dl,{ox+sz*.5f,oy+sz*.5f},sz*.5f,rng);
    else if(cfg::radar::style==1)
        draw_square(dl,{ox,oy},sz,rng);
    else
        draw_arrow(dl,{ox,oy},sz,rng);
    g_cnt=0;
}

} // namespace radar
