#pragma once

#include "game.hpp"
#include "math.hpp"
#include "player.hpp"
#include "ui/cfg.hpp"
#include <vector>
#include <cmath>

namespace aimbot {

    struct Target {
        uint64_t object;
        Vector3 head_pos;
        Vector3 body_pos;
        float distance;
        float fov_to_target;
        int team;
    };

    inline Vector3 get_bone_pos(uint64_t player, int bone) {
        // For now, approximate: bone 0 = head, others = body
        Vector3 pos = player::position(player);
        if (bone == 0) {
            pos.y += 1.67f; // head offset
        }
        return pos;
    }

    inline float get_fov_to_target(const Vector3& local_pos, const Vector4& local_rot, const Vector3& target_pos) {
        Vector3 to_target = Vector3{
            target_pos.x - local_pos.x,
            target_pos.y - local_pos.y,
            target_pos.z - local_pos.z
        };
        float dist = std::sqrt(to_target.x * to_target.x + to_target.y * to_target.y + to_target.z * to_target.z);
        if (dist < 0.01f) return 0.f;

        Vector3 forward = player::rotate(Vector4{0,0,0,1}, Vector3(0.f, 0.f, 1.f)); // placeholder
        // Actually we need the local player's view rotation
        // This will be called with the view rotation passed in
        return 0.f;
    }

    inline Target find_best_target(const Vector3& local_pos, const Vector4& view_rot) {
        Target best{};
        best.fov_to_target = cfg::aim::fov;

        std::vector<uint64_t> players = player::players();
        if (players.empty()) return best;

        const uint64_t local_player = 0;
        for (uint64_t p : players) {
            if (player::local(p)) { local_player = p; break; }
        }
        if (!local_player) return best;

        int local_team = player::team(local_player);

        for (uint64_t p : players) {
            if (p == local_player) continue;
            if (!player::health(p)) continue;

            int pteam = player::team(p);
            if (cfg::aim::team_check && pteam == local_team) continue;

            Vector3 head = get_bone_pos(p, cfg::aim::bone);
            Vector3 body = get_bone_pos(p, 1);

            Vector3 to_head = {head.x - local_pos.x, head.y - local_pos.y, head.z - local_pos.z};
            float dist = std::sqrt(to_head.x * to_head.x + to_head.y * to_head.y + to_head.z * to_head.z);
            if (dist > cfg::aim::max_dist || dist < 0.1f) continue;

            Vector3 forward = player::rotate(view_rot, Vector3(0.f, 0.f, 1.f));
            Vector3 to_target = {head.x - local_pos.x, head.y - local_pos.y, head.z - local_pos.z};
            float target_dist = std::sqrt(to_target.x * to_target.x + to_target.y * to_target.y + to_target.z * to_target.z);
            if (target_dist < 0.01f) continue;

            to_target.x /= target_dist;
            to_target.y /= target_dist;
            to_target.z /= target_dist;

            float dot = forward.x * to_target.x + forward.y * to_target.y + forward.z * to_target.z;
            if (dot < -1.f) dot = -1.f;
            if (dot > 1.f) dot = 1.f;
            float angle = std::acos(dot) * 57.29578f;

            if (angle < best.fov_to_target) {
                best.fov_to_target = angle;
                best.object = p;
                best.head_pos = head;
                best.body_pos = body;
                best.distance = dist;
                best.team = pteam;
            }
        }

        return best;
    }

    inline void run_aimbot(uint64_t local_player, const Vector4& view_rot) {
        if (!cfg::aim::enabled) return;
        if (!local_player) return;

        Vector3 local_pos = player::position(local_player);
        if (local_pos.x == 0.f && local_pos.y == 0.f && local_pos.z == 0.f) return;

        Target target = find_best_target(local_pos, view_rot);
        if (!target.object) return;

        // Calculate required view rotation to aim at target
        Vector3 target_pos = (cfg::aim::bone == 0) ? target.head_pos : target.body_pos;
        Vector3 delta = {
            target_pos.x - local_pos.x,
            target_pos.y - local_pos.y,
            target_pos.z - local_pos.z
        };
        float dist = std::sqrt(delta.x * delta.x + delta.y * delta.y + delta.z * delta.z);
        if (dist < 0.01f) return;

        delta.x /= dist;
        delta.y /= dist;
        delta.z /= dist;

        // Current forward
        Vector3 forward = player::rotate(view_rot, Vector3(0.f, 0.f, 1.f));

        // Calculate target rotation (simplified: just yaw/pitch toward target)
        float yaw = std::atan2(delta.x, delta.z) * 57.29578f;
        float pitch = -std::asin(std::clamp(delta.y, -1.f, 1.f)) * 57.29578f;

        // Convert current view_rot to euler
        // Quaternion to euler (simplified)
        float cy = std::cos(view_rot.w * 0.5f);
        float sy = std::sin(view_rot.w * 0.5f);
        // This is oversimplified - need proper quaternion to euler

        // For now, just write the aim state if we have a write primitive
        // TODO: implement proper quaternion slerp and write

        static long long aim_log = 0;
        if (diag::every(aim_log, 1000)) {
            diag::log("AIM", "target=%s dist=%.1f fov=%.1f", player::name(target.object).c_str(), target.distance, target.fov_to_target);
        }
    }

}